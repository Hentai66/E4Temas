#ifndef THEMES_STARTUP_H
#define THEMES_STARTUP_H
#include <3ds.h>
typedef struct {
    Result detected_result, writable_result;
    bool detected, writable;
} ThemeBootInfo;
void startup_begin(const char *name, ThemeBootInfo *info);
void startup_record(const char *stage, Result result);
#endif
