#ifndef E4_CLEANUP_H
#define E4_CLEANUP_H
#include "tt.h"
/* Policy only; callers must also confirm install, finalization and unchanged hash. */
TT_API int e4_can_delete_input(const char *path);
#endif
