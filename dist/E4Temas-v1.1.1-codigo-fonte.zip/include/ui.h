#ifndef E4_UI_H
#define E4_UI_H
#include <stdint.h>
typedef struct {uint32_t bg,panel,text,muted,accent;} UIPalette;
extern UIPalette ui_colors;
void ui_theme(int light);
void ui_surface(unsigned char *pixels,int width);
void ui_rect(int x,int y,int w,int h,uint32_t color);
void ui_text(int x,int y,const char *text,uint32_t color,int max_chars);
void ui_logo(int x,int y);
void ui_clear(void);
#endif
