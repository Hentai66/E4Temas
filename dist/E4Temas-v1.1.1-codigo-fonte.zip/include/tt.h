#ifndef TEMAS3DS_TT_H
#define TEMAS3DS_TT_H
#include <stddef.h>
#include <stdint.h>

#define TT_MAX_CONTENTS 101
#define TT_ERROR_SIZE 256
#ifdef _WIN32
#define TT_API __declspec(dllexport)
#else
#define TT_API
#endif
typedef struct {
    uint32_t id;
    uint16_t index, type;
    uint64_t size, offset;
    unsigned char hash[32];
} TTContent;
typedef struct {
    uint64_t title_id, file_size;
    uint16_t version, count;
    uint32_t cert_size, ticket_size, tmd_size;
    uint64_t cert_offset, ticket_offset, tmd_offset, content_offset;
    TTContent contents[TT_MAX_CONTENTS];
} TTPackage;

typedef void (*TTProgress)(const char *stage, unsigned percent);
TT_API void tt_set_progress(TTProgress callback);
void tt_progress(const char *stage, unsigned percent);
/* Fast structural filter, not a substitute for full import validation. */
TT_API int tt_is_theme_cia(const char *path);

/* All operations are offline. The library never installs or deletes a title. */
TT_API int tt_inspect(const char *cia, TTPackage *package, char *error);
TT_API int tt_verify(const char *cia, char *error);
TT_API int tt_add(const char *base_cia, const char *theme_folder,
           const char *candidate_cia, char *error);
TT_API int tt_repair(const char *base_cia, const char *candidate_cia, char *error);
/* Testable format primitives; returned buffers are released using tt_free. */
TT_API void tt_sha256(const void *data, size_t size, unsigned char hash[32]);
TT_API int tt_lz11(const unsigned char *data, size_t size,
            unsigned char **output, size_t *output_size, char *error);
TT_API void tt_free(void *buffer);
#endif
