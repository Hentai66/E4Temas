"""Adapt the user's original SVG and 3.2-second HTML/CSS E4T animation for 3DS."""
from pathlib import Path
import struct
import subprocess
import wave
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
BG=(252,239,223)

def ease(x):
    lo,hi=0.,1.
    for _ in range(24):
        t=(lo+hi)/2
        bx=3*(1-t)**2*t*.25+3*(1-t)*t*t*.25+t**3
        if bx<x:lo=t
        else:hi=t
    t=(lo+hi)/2
    return 3*(1-t)**2*t*.1+3*(1-t)*t*t+t**3

def track(t,points):
    for (a,va),(b,vb) in zip(points,points[1:]):
        if t<=b:return va+(vb-va)*ease(max(0.,(t-a)/(b-a)))
    return points[-1][1]

def svg(parts,width=400,height=240):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="#fcefdf"/>{parts}</svg>'

def render(tool,markup,stem,work):
    source=work/(stem+'.svg');target=work/(stem+'.png')
    source.write_text(markup,encoding='utf-8')
    subprocess.run([str(tool),str(source),str(target)],check=True,capture_output=True)
    return Image.open(target).convert('RGB')

def rle(image):
    values=[((r>>3)<<11)|((g>>2)<<5)|(b>>3) for r,g,b in image.getdata()]
    encoded=bytearray();previous=values[0];run=0
    for value in values:
        if value==previous and run<65535:run+=1
        else:encoded.extend(struct.pack('<HH',run,previous));previous=value;run=1
    encoded.extend(struct.pack('<HH',run,previous))
    decoded=[]
    for off in range(0,len(encoded),4):
        count,value=struct.unpack_from('<HH',encoded,off);decoded.extend([value]*count)
    assert decoded==values
    return encoded

def generate():
    out=ROOT/'assets';work=ROOT/'.research'/'animation';work.mkdir(parents=True,exist_ok=True)
    tool=ROOT/'.toolchain'/'resvg'/'resvg.exe'
    if not tool.exists():raise SystemExit('Provide resvg 0.49.0 at .toolchain/resvg/resvg.exe')
    tree=ET.parse(out/'reference'/'E4T.svg').getroot()
    parts=[ET.tostring(child,encoding='unicode') for child in tree]
    assert len(parts)==4
    artwork=''.join(parts)
    icon_markup='<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="180 140 940 940"><rect x="180" y="140" width="940" height="940" fill="#fcefdf"/>'+artwork+'</svg>'
    render(tool,icon_markup,'icon',work).save(out/'icon.png')
    mark=render(tool,svg(f'<g transform="translate(8 -4) scale(.112)">{artwork}</g>',146,128),'banner-mark',work)
    banner=Image.new('RGB',(256,128),BG);banner.paste(mark,(0,0))
    font=ImageFont.truetype(r'C:\Windows\Fonts\segoeuib.ttf',23)
    ImageDraw.Draw(banner).text((139,48),'E4Temas',font=font,fill='#54058b')
    banner.save(out/'banner.png')
    with wave.open(str(out/'silence.wav'),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(22050);wav.writeframes(bytes(11024))
    animation=bytearray(struct.pack('<4s4H',b'E4A1',400,240,64,20));previews=[]
    for frame in range(64):
        t=frame/64
        opacity=track(t,[(0,0),(.2,1),(.7,1),(.76,1),(.87,1),(.97,0),(1,0)])
        translated=track(t,[(0,1),(.2,0),(.7,0),(.76,0),(.97,1),(1,1)])
        groups=[]
        for piece,sign,end_angle in [(parts[0],-1,328),(parts[1],1,392)]:
            angle=track(t,[(0,-25),(.2,0),(.7,360),(.76,360),(.97,end_angle),(1,end_angle)])
            tx=sign*312*translated;ty=sign*278.3*translated
            transform=f'translate({tx} {ty}) translate(648.96 620.972) rotate({angle}) translate(-648.96 -620.972)'
            groups.append(f'<g transform="{transform}" opacity="{opacity}">{piece}</g>')
        groups.extend(parts[2:])
        markup=svg('<g transform="translate(80 8) scale(.184615384615)">'+''.join(groups)+'</g>')
        image=render(tool,markup,f'frame-{frame:02}',work)
        data=rle(image);animation.extend(struct.pack('<I',len(data)));animation.extend(data)
        if frame in [0,12,28,42,52,62]:previews.append(image)
    (out/'intro.e4a').write_bytes(animation)
    sheet=Image.new('RGB',(800,720),BG)
    for i,image in enumerate(previews):sheet.paste(image,((i%2)*400,(i//2)*240))
    sheet.save(out/'animation-preview.png')
    print('Original E4T animation adapted to 64 native frames:',len(animation),'bytes')
    return out

if __name__=='__main__':generate()
