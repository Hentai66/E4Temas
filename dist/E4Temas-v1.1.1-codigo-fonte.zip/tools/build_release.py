"""Build both E4Temas applications with identical self-contained resources."""
from pathlib import Path
import argparse
import subprocess
from build_host import build as build_host
from build_3ds import build as build_3ds
from build_app_cia import build as build_cia
from create_ui_assets import generate
from create_bases import create

ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--devkitpro')
    parser.add_argument('--cc')
    parser.add_argument('--makerom',type=Path,default=ROOT/'.toolchain'/'makerom'/'makerom.exe')
    parser.add_argument('--bannertool',type=Path,default=ROOT/'.toolchain'/'bannertool'/'windows-x86_64'/'bannertool.exe')
    args=parser.parse_args()
    build_host(args.cc)
    create(args.makerom)
    generate()
    subprocess.run([str(args.bannertool),'makesmdh','-s','E4Temas','-l','Gerenciador de temas - experimental',
                    '-p','E4T','-i',str(ROOT/'assets'/'icon.png'),'-o',str(ROOT/'build'/'icon.smdh')],check=True)
    build_3ds(args.devkitpro)
    build_cia(args.makerom,args.bannertool)
