"""Package verified build outputs, sources and an explicit validation report."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
NAMES=['e4temas-v1.1.1.3dsx','e4temas-v1.1.1.cia']

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def pack():
    from audit_launch_profile import audit
    profile=audit(ROOT/'build'/'3ds'/'e4temas.cia',int('000400000F5C1E00',16))
    assert not profile['issues'],profile['issues']
    assert profile['title_version']==1041
    DIST.mkdir(exist_ok=True)
    for name in NAMES:
        shutil.copy2(ROOT/'build'/'3ds'/name.replace('-v1.1.1',''),DIST/name)
    hashes={name:digest(DIST/name) for name in NAMES}
    report='# E4Temas 1.1.1 - revisao visual\n\nLogos atualizados; animacao de areia preservada byte a byte.\nNucleo funcional identico a 1.1.1 confirmada pelo usuario no console.\nInterface e fila verificadas localmente; CIA/3DSX e banner conferidos.\nEsta revisao visual ainda aguarda teste no console.\n\n## SHA-256\n\n'
    for name,sha in hashes.items():report+=f'- `{name}`: `{sha}`\n'
    (ROOT/'docs'/'BUILD_REPORT.md').write_text(report,encoding='utf-8')
    quick='E4Temas 1.1.1\n\nFBI: versao 1.1.1. Instale e4temas-v1.1.1.cia ou abra o 3DSX no Homebrew Launcher.\nPreserve /3ds/scl-temas/. Colecao ja funcional nao precisa de novo reparo.\n\nSELECT: aparencia; escolha Lista violeta ou Lilas claro, A salva.\nA: abrir pasta / escolher CIA. X: marcar/desmarcar CIA. Y: revisar fila.\nNa revisao, X ativa/desativa apagar CIAs apos instalar (padrao NAO).\nL + R + A confirma. Exclusao somente apos TODA a fila concluir com sucesso.\nB: voltar. R: ferramentas. START: sair.\n\nLeia UI_RELEASE.md. Novos recursos ainda aguardam confirmacao no console.\n'
    (DIST/'LEIA-ME.txt').write_text(quick,encoding='utf-8')
    archive=DIST/'E4Temas-v1.1.1-experimental.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(DIST/'e4temas-v1.1.1.3dsx','3ds/e4temas-v1.1.1.3dsx')
        z.write(DIST/'e4temas-v1.1.1.cia','e4temas-v1.1.1.cia')
        z.write(DIST/'LEIA-ME.txt','LEIA-ME.txt')
        for source,target in [('README.md','README.md'),('LICENSE','LICENSE'),
                              ('docs/BUILD_REPORT.md','BUILD_REPORT.md'),
                              ('docs/UI_RELEASE.md','UI_RELEASE.md'),
                              ('docs/PERFORMANCE_111.md','PERFORMANCE_111.md'),
                              ('docs/STARTUP_FIX.md','STARTUP_FIX.md'),
                              ('docs/CATALOG_FIX.md','CATALOG_FIX.md'),
                              ('docs/CATALOG_COMPARISON.json','CATALOG_COMPARISON.json'),
                              ('docs/HARDWARE_TESTS.md','HARDWARE_TESTS.md'),
                              ('vendor/miniz-LICENSE','licenses/miniz-LICENSE'),
                              ('vendor/stb_image.h','licenses/stb_image.h')]:
            z.write(ROOT/source,target)
    source_archive=DIST/'E4Temas-v1.1.1-codigo-fonte.zip'
    files=[]
    for name in ['README.md','STATUS.md','LICENSE','app.rsf','.gitignore','.clang-format']:
        files.append(ROOT/name)
    for folder in ['assets','docs','include','source','tests','tools','vendor']:
        files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    with zipfile.ZipFile(source_archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(files):z.write(path,str(path.relative_to(ROOT)))
    for path in (archive,source_archive):hashes[path.name]=digest(path)
    (DIST/'SHA256SUMS.txt').write_text(''.join(f'{sha}  {name}\n' for name,sha in hashes.items()),encoding='ascii')
    # Verify that delivery packaging did not change either executable.
    with zipfile.ZipFile(archive) as z:
        assert z.read('3ds/e4temas-v1.1.1.3dsx')==(DIST/'e4temas-v1.1.1.3dsx').read_bytes()
        assert z.read('e4temas-v1.1.1.cia')==(DIST/'e4temas-v1.1.1.cia').read_bytes()
    print(json.dumps({name:{'bytes':(DIST/name).stat().st_size,'sha256':sha} for name,sha in hashes.items()},indent=2))
    return archive

if __name__=='__main__':pack()
