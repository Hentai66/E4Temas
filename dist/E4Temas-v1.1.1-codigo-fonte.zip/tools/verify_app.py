"""Independent ctrtool validation and extraction of the built application CIA."""
from pathlib import Path
import hashlib
import re
import struct
import subprocess
from audit_launch_profile import audit

ROOT=Path(__file__).resolve().parents[1]

def verify(tool=None):
    tool=Path(tool or ROOT/'.toolchain'/'ctrtool'/'ctrtool.exe')
    out=ROOT/'build'/'validation';out.mkdir(parents=True,exist_ok=True)
    launch=audit(ROOT/'build'/'3ds'/'e4temas.cia')
    assert not launch['issues'],launch['issues']
    assert launch['title_version']==1041,'Expected 1.1.1 (1041), newer than v1026'
    import json
    (out/'launch-profile.json').write_text(json.dumps(launch,indent=2),encoding='utf-8')
    exefs=out/'app-exefs';romfs=out/'app-romfs'
    exefs.mkdir(exist_ok=True);romfs.mkdir(exist_ok=True)
    result=subprocess.run([str(tool),'--verify','--exefsdir='+str(exefs),'--romfsdir='+str(romfs),
                           str(ROOT/'build'/'3ds'/'e4temas.cia')],capture_output=True,text=True)
    report=result.stdout+result.stderr
    # These are generated dummy keys, but they are irrelevant to the report.
    report='\n'.join(line for line in report.splitlines() if 'TitleKey:' not in line)+'\n'
    (out/'app-ctrtool.txt').write_text(report,encoding='utf-8')
    bad_hashes=[line for line in report.splitlines() if re.search(r'hash.*\(FAIL\)',line,re.I)]
    if bad_hashes:
        raise RuntimeError('\n'.join(bad_hashes))
    for region in ('JPN','USA','EUR'):
        expected=(ROOT/'build'/'bases'/(region+'.cia')).read_bytes()
        actual=(romfs/(region+'.cia')).read_bytes()
        assert actual==expected,region+' base differs'
    icon=(exefs/'icon.bin').read_bytes()
    assert icon[:4]==b'SMDH'
    title=icon[0x208:0x288].decode('utf-16le').split('\0',1)[0]
    assert title=='E4Temas',title
    assert (exefs/'banner.bin').read_bytes()==(ROOT/'build'/'banner.bnr').read_bytes()
    assert (romfs/'intro.e4a').read_bytes()==(ROOT/'assets'/'intro.e4a').read_bytes()
    magic,width,height,frames,fps=struct.unpack_from('<4s4H',(romfs/'intro.e4a').read_bytes())
    assert (magic,width,height,frames,fps)==(b'E4A1',400,240,44,20)
    animation=(romfs/'intro.e4a').read_bytes();cursor=12
    for frame in range(frames):
        size=struct.unpack_from('<I',animation,cursor)[0];cursor+=4
        assert size and size%4==0 and cursor+size<=len(animation)
        pixels=0
        for count,color in struct.iter_unpack('<HH',animation[cursor:cursor+size]):
            assert count>0;pixels+=count
        assert pixels==400*240
        cursor+=size
    assert cursor==len(animation)
    program=(ROOT/'build'/'3ds'/'e4temas.3dsx').read_bytes()
    assert program[:4]==b'3DSX'
    assert struct.unpack_from('<H',program,4)[0]>=0x2C
    smdh_offset,smdh_size,romfs_offset=struct.unpack_from('<3I',program,0x20)
    assert program[smdh_offset:smdh_offset+4]==b'SMDH'
    assert program[smdh_offset:smdh_offset+smdh_size]==(ROOT/'build'/'icon.smdh').read_bytes()
    assert program[romfs_offset:]==(ROOT/'build'/'resources.romfs').read_bytes()
    print('CIA: icon name, banner, embedded JPN/USA/EUR bases and hashes checked with ctrtool.')
    print('3DSX: header, embedded SMDH and complete embedded RomFS checked.')
    print('Unsigned homebrew signatures are expected to fail retail signature verification.')
    print('Hardware execution and native HOME Menu behavior remain untested.')
    return out/'app-ctrtool.txt'

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--ctrtool')
    verify(parser.parse_args().ctrtool)
