"""Package the application (not a theme) into an installable CIA."""
from pathlib import Path
import argparse
import hashlib
import subprocess
import struct
ROOT=Path(__file__).resolve().parents[1]

def set_homebrew_version(path, version):
    """Keep ticket/TMD version consistent despite this makerom build resetting minor.

    These are test-key homebrew CIAs, already requiring CFW signature patches.
    Version fields are outside content hash tables. Never apply to retail CIAs.
    """
    from audit_launch_profile import audit
    profile=audit(path,0x000400000F5C1E00)
    assert not profile['issues'],profile['issues']
    data=bytearray(path.read_bytes());align=lambda n:(n+63)&~63
    cert,ticket_size,tmd_size=struct.unpack_from('<3I',data,8)
    ticket=align(align(0x2020)+cert);tmd=align(ticket+ticket_size)
    assert struct.unpack_from('>I',data,ticket)[0]==0x10004
    assert struct.unpack_from('>I',data,tmd)[0]==0x10004
    struct.pack_into('>H',data,ticket+0x1E6,version)
    struct.pack_into('>H',data,tmd+0x1DC,version)
    data[ticket+4:ticket+260]=b'\xff'*256
    data[tmd+4:tmd+260]=b'\xff'*256
    path.write_bytes(data)
    assert audit(path)['title_version']==version

def build(makerom=None,bannertool=None):
    makerom=Path(makerom or ROOT/'.toolchain'/'makerom'/'makerom.exe')
    bannertool=Path(bannertool or ROOT/'.toolchain'/'bannertool'/'windows-x86_64'/'bannertool.exe')
    out=ROOT/'build';(out/'3ds').mkdir(parents=True,exist_ok=True)
    subprocess.run([str(bannertool),'makesmdh','-s','E4Temas','-l','Gerenciador de temas - experimental',
                    '-p','E4T','-i',str(ROOT/'assets'/'icon.png'),'-o',str(out/'icon.smdh')],check=True)
    subprocess.run([str(bannertool),'makebanner','-i',str(ROOT/'assets'/'banner.png'),
                    '-a',str(ROOT/'assets'/'silence.wav'),'-o',str(out/'banner.bnr')],check=True)
    target=out/'3ds'/'e4temas.cia'
    subprocess.run([str(makerom),'-f','cia','-rsf',str(ROOT/'app.rsf'),'-target','t',
                    '-elf',str(out/'3ds'/'e4temas.elf'),'-icon',str(out/'icon.smdh'),
                    '-banner',str(out/'banner.bnr'),'-romfs',str(out/'resources.romfs'),
                    '-exefslogo','-major','1','-minor','1','-micro','1','-o',str(target)],check=True)
    set_homebrew_version(target,1041)
    print(f'{target}\nSHA256 {hashlib.sha256(target.read_bytes()).hexdigest()}')
    return target

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--makerom')
    parser.add_argument('--bannertool')
    args=parser.parse_args();build(args.makerom,args.bannertool)
