"""Audit executable CIA launch metadata, independently of makerom's file hashes.

Layout/flags: Project_CTR makerom exheader.h and the Anemone3DS CIA profile.
No console keys or proprietary binaries are required.
"""
from pathlib import Path
import argparse
import json
import struct

def audit(path,expected_id=None):
    data=Path(path).read_bytes();align=lambda n:(n+63)&~63
    if len(data)<0x2020 or struct.unpack_from('<I',data)[0]!=0x2020:
        raise ValueError('Not a complete CIA')
    cert_size,ticket_size,tmd_size=struct.unpack_from('<3I',data,8)
    ticket=align(align(0x2020)+cert_size);tmd=align(ticket+ticket_size)
    content=align(tmd+tmd_size)
    if data[content+0x100:content+0x104]!=b'NCCH':raise ValueError('Missing NCCH')
    if not data[content+0x18F]&4:raise ValueError('Audit requires plaintext homebrew NCCH')
    ex=data[content+0x200:content+0xA00]
    if len(ex)!=0x800:raise ValueError('Missing executable ExHeader')
    tid=struct.unpack_from('>Q',data,tmd+0x18C)[0]
    identities={
        'tmd':tid,
        'ticket':struct.unpack_from('>Q',data,ticket+0x1DC)[0],
        'ncch':struct.unpack_from('<Q',data,content+0x118)[0],
        'jump':struct.unpack_from('<Q',ex,0x1C8)[0],
        'access_control':struct.unpack_from('<Q',ex,0x200)[0],
    }
    fs=int.from_bytes(ex[0x248:0x24F],'little')
    services=[ex[i:i+8].split(b'\0',1)[0].decode('ascii') for i in range(0x250,0x360,8) if ex[i]]
    exeoffset,exesize=struct.unpack_from('<2I',data,content+0x1A0)
    entries={}
    for off in range(0,160,16):
        name=data[content+exeoffset*512+off:content+exeoffset*512+off+8].split(b'\0',1)[0].decode('ascii')
        if name:
            pos,size=struct.unpack_from('<2I',data,content+exeoffset*512+off+8)
            if 512+pos+size>exesize*512:raise ValueError('ExeFS entry out of bounds')
            entries[name]=size
    issues=[]
    if len(set(identities.values()))!=1:issues.append('Title IDs disagree across launch metadata')
    if expected_id is not None and tid!=expected_id:issues.append('Unexpected application Title ID')
    if not ex[0xD]&2:issues.append('SD application flag is missing')
    if fs&0x8080!=0x8080:issues.append('DirectSdmc/DirectSdmcWrite permissions incomplete')
    required={'APT:U','fs:USER','gsp::Gpu','hid:USER','cfg:u','am:net','am:app'}
    missing=required-set(services)
    if missing:issues.append('Missing service declarations: '+', '.join(sorted(missing)))
    if entries.get('logo',0)!=0x2000:issues.append('Homebrew launch logo is missing from ExeFS')
    if not entries.get('.code'):issues.append('Executable .code section is missing')
    version=struct.unpack_from('>H',data,tmd+0x1DC)[0]
    return {'title_ids':{name:f'{value:016X}' for name,value in identities.items()},
            'title_version':version,'fs_access':f'{fs:014X}','services':services,
            'exefs':entries,'issues':issues,'hardware_launch_proven':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('cia',type=Path)
    parser.add_argument('--expected-id',type=lambda x:int(x,16));parser.add_argument('--report',type=Path)
    parser.add_argument('--allow-legacy',action='store_true');args=parser.parse_args()
    report=audit(args.cia,args.expected_id);text=json.dumps(report,indent=2)
    if args.report:args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(text,encoding='utf-8')
    print(text)
    if report['issues'] and not args.allow_legacy:raise SystemExit(1)
