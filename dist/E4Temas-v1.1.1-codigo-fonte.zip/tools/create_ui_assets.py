"""Rasterize original vector assets and the supplied sand animation for native 3DS."""
from pathlib import Path
import math,struct,subprocess,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFont
from create_e4_assets import rle,track
ROOT=Path(__file__).resolve().parents[1]
def generate_sand_reference():
    out=ROOT/'assets';work=ROOT/'.research/sand';work.mkdir(parents=True,exist_ok=True)
    tool=ROOT/'.toolchain/resvg/resvg.exe'
    parts=[ET.tostring(c,encoding='unicode') for c in ET.parse(out/'reference/E4T.svg').getroot()]
    parts[0]=parts[0].replace('#54058b','#a05ce7')
    def render(body,stem,w=400,h=240,view=None):
        src=work/(stem+'.svg');dst=work/(stem+'.png')
        src.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="{view or f"0 0 {w} {h}"}">{body}</svg>',encoding='utf-8')
        subprocess.run([str(tool),str(src),str(dst)],capture_output=True,check=True)
        return Image.open(dst).convert('RGBA')
    logo=render(''.join(parts),'logo',32,32,'180 140 940 940')
    mark=render(''.join(parts),'banner-mark',128,128,'180 140 940 940')
    banner=Image.new('RGBA',(256,128),(0,0,0,0));banner.alpha_composite(mark,(0,0))
    font=ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf',23)
    ImageDraw.Draw(banner).text((130,48),'E4Temas',font=font,fill='#a05ce7')
    banner.save(out/'banner.png')
    # SMDH small icons use RGB565 and cannot carry alpha; use the chosen charcoal palette.
    icon=render('<rect x="180" y="140" width="940" height="940" fill="#181b1d"/>'+''.join(parts),'icon',48,48,'180 140 940 940')
    icon.convert('RGB').save(out/'icon.png')
    font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14)
    glyphs=bytearray()
    for code in range(256):
        tile=Image.new('L',(8,16));ImageDraw.Draw(tile).text((0,-1),chr(code) if code>=32 else ' ',font=font,fill=255)
        glyphs.extend(tile.tobytes())
    def carray(name,data):return 'static const unsigned char '+name+'[] = {\n'+','.join(str(x) for x in data)+'\n};\n'
    (ROOT/'source/ui_assets.h').write_text(carray('e4_font',glyphs)+carray('e4_logo',logo.tobytes()),encoding='ascii')
    animation=bytearray(struct.pack('<4s4H',b'E4A1',400,240,44,20));preview=[]
    for frame in range(44):
        time=frame/20;t=time/2.2;groups=[]
        angle=track(t,[(0,0),(.5,0),(.86,360),(1,360)])
        for piece,shape,bounds in [('top',parts[0],(328,173,966,581)),('bottom',parts[1],(230,666,1070,1040))]:
            left,top,right,bottom=bounds;defs=[];fragments=[];index=0;direction=-1 if piece=='top' else 1
            for y in range(top,bottom,34):
                shift=((y-top)//34%2)*17
                for x in range(left-shift,right,34):
                    phase=abs(math.sin(x*1.27+y*.83));arrival=abs(math.sin((index+1)*13.7));local=max(0.,time-arrival*.16)/2.2
                    dx=round((phase-.5)*300);dy=direction*round(85+phase*130)
                    tx=track(local,[(0,0),(.82,0),(.94,dx),(1,dx)])
                    ty=track(local,[(0,direction*(370+arrival*690)),(.05,direction*(370+arrival*690)),(.34,-direction*12),(.42,0),(.82,0),(.94,dy),(1,dy)])
                    opacity=track(local,[(0,0),(.05,0),(.13,1),(.82,1),(.94,.8),(1,0)])
                    ident=f'{piece}{index}';defs.append(f'<clipPath id="{ident}"><rect x="{x}" y="{y}" width="34" height="34"/></clipPath>')
                    fragments.append(f'<g transform="translate({tx} {ty})" opacity="{opacity}"><g clip-path="url(#{ident})">{shape}</g></g>');index+=1
            groups.append('<defs>'+''.join(defs)+'</defs>'+f'<g transform="rotate({angle} 648.96 620.972)">'+''.join(fragments)+'</g>')
        opacity=track(t,[(0,0),(.5,0),(.55,.9),(.86,.9),(.94,.48),(1,0)])
        outer=track(t,[(0,0),(.5,0),(.86,720),(1,990)])
        inner=track(t,[(0,0),(.5,0),(.86,1080),(1,1450)])
        arcs=f'<g transform="translate(45 -35) scale(1.55)" opacity="{opacity}"><g transform="rotate({outer} 100 100)" stroke="#bc83fa" stroke-width="4" fill="none"><path d="M28 100 A72 72 0 0 1 145 44 M172 100 A72 72 0 0 1 55 156"/></g><circle cx="100" cy="100" r="58" transform="rotate({inner} 100 100)" stroke="#d8b5ff" stroke-width="3" stroke-dasharray="70 31 38 39 68 118" fill="none"/></g>'
        body='<rect width="400" height="240" fill="#181b1d"/>'+arcs+'<g transform="translate(80 8) scale(.184615384615)">'+''.join(groups)+''.join(parts[2:])+'</g>'
        image=render(body,f'frame-{frame:02}').convert('RGB');encoded=rle(image);animation.extend(struct.pack('<I',len(encoded)));animation.extend(encoded)
        preview.append(image)
    (out/'intro.e4a').write_bytes(animation)
    preview[0].save(out/'sand-preview.gif',save_all=True,append_images=preview[1:],duration=50,loop=0)
    print('Sand animation:',len(animation),'bytes; 44 frames; transparent banner generated')
from compile_branding import generate
if __name__=='__main__':generate()
