"""Build the actual 3DSX using an existing, supported devkitPro installation.

Also understands the workspace-local toolchain used during development.
"""
from pathlib import Path
import argparse
import ctypes
import hashlib
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def short_path(path):
    path = str(path)
    if os.name != 'nt':
        return path
    buf = ctypes.create_unicode_buffer(32768)
    if ctypes.windll.kernel32.GetShortPathNameW(path, buf, len(buf)):
        return buf.value
    return path

def build(devkitpro=None):
    dkp = Path(devkitpro or os.environ.get('DEVKITPRO', ROOT/'.toolchain'/'opt'/'devkitpro')).resolve()
    arm = dkp/'devkitARM'
    exe = '.exe' if os.name == 'nt' else ''
    cc = arm/'bin'/('arm-none-eabi-gcc'+exe)
    tool = dkp/'tools'/'bin'/('3dsxtool'+exe)
    if not cc.exists() or not tool.exists():
        raise SystemExit('Instale devkitARM, libctru e 3ds-tools pelo pacman do devkitPro; configure DEVKITPRO.')
    env = os.environ.copy()
    env['DEVKITPRO'] = short_path(dkp).replace('\\','/')
    env['DEVKITARM'] = short_path(arm).replace('\\','/')
    env['PATH'] = str(arm/'bin')+os.pathsep+str(dkp/'tools'/'bin')+os.pathsep+env['PATH']
    out = ROOT/'build'/'3ds'
    out.mkdir(parents=True,exist_ok=True)
    flags = ['-std=gnu11','-O2','-g','-Wall','-Wextra','-Wno-misleading-indentation',
             '-ffunction-sections','-fdata-sections','-march=armv6k','-mtune=mpcore',
             '-mfloat-abi=hard','-mtp=soft','-mword-relocations',
             '-DMINIZ_NO_ARCHIVE_APIS','-DMINIZ_NO_DEFLATE_APIS','-DMINIZ_NO_ZLIB_APIS',
             '-I'+str(ROOT/'vendor'),'-I'+str(ROOT/'include'),'-I'+str(ROOT/'source'),'-I'+str(dkp/'libctru'/'include')]
    objects=[]
    for source in ('source/main.c','source/startup.c','source/intro.c','source/ui.c','source/cleanup.c','source/format.c','source/sha256.c','source/import.c','vendor/miniz_tinfl.c'):
        obj=out/(Path(source).stem+'.o')
        subprocess.run([str(cc),*flags,'-c',str(ROOT/source),'-o',str(obj)],env=env,check=True)
        objects.append(str(obj))
    elf=out/'e4temas.elf'
    specs=arm/'arm-none-eabi'/'lib'/'3dsx.specs'
    subprocess.run([str(cc),*flags,'-specs='+short_path(specs),*objects,
                    '-L'+str(dkp/'libctru'/'lib'),'-lctru','-lm',
                    '-Wl,--gc-sections','-Wl,-Map,'+str(out/'e4temas.map'),'-o',str(elf)],env=env,check=True)
    sys.path.insert(0,str(ROOT/'tests'))
    from reference import romfs
    bases=ROOT/'build'/'bases'
    resources=ROOT/'build'/'resources.romfs'
    files={name+'.cia':(bases/(name+'.cia')).read_bytes() for name in ('JPN','USA','EUR')}
    files['intro.e4a']=(ROOT/'assets'/'intro.e4a').read_bytes()
    resources.write_bytes(romfs(files))
    output=out/'e4temas.3dsx'
    subprocess.run([str(tool),str(elf),str(output),'--romfs='+str(resources),'--smdh='+str(ROOT/'build'/'icon.smdh')],env=env,check=True)
    print(f'{output}\nSHA256 {hashlib.sha256(output.read_bytes()).hexdigest()}')
    return output

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--devkitpro')
    build(parser.parse_args().devkitpro)
