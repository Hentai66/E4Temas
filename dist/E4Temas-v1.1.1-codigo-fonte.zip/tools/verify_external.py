"""Check generated files with independently maintained ctrtool, using synthetic data."""
from pathlib import Path
import ctypes
import os
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from reference import body

if __name__=='__main__':
    folder=ROOT/'build'/'validation';folder.mkdir(parents=True,exist_ok=True)
    theme=folder/'theme';theme.mkdir(exist_ok=True)
    (theme/'body_LZ.bin').write_bytes(body(77))
    (theme/'name.txt').write_text('Teste estrutural',encoding='utf-8')
    output=folder/'candidate.cia'
    if output.exists():output.unlink()
    lib=ctypes.CDLL(str(ROOT/'build'/'temas3ds.dll'))
    error=ctypes.create_string_buffer(256)
    rc=lib.tt_add(os.fsencode(ROOT/'build'/'bases'/'USA.cia'),os.fsencode(theme),os.fsencode(output),error)
    if rc:raise SystemExit(error.value.decode())
    tool=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'.toolchain'/'ctrtool'/'ctrtool.exe'
    result=subprocess.run([str(tool),'--verify',str(output)],capture_output=True,text=True)
    text=result.stdout+result.stderr
    text='\n'.join(line for line in text.splitlines() if 'TitleKey:' not in line)+'\n'
    (folder/'ctrtool.txt').write_text(text,encoding='utf-8')
    bad=[line for line in text.splitlines() if re.search(r'hash.*\(FAIL\)|Level [0-9]+: \(FAIL\)',line,re.I)]
    if bad:raise SystemExit('\n'.join(bad))
    print('Theme CIA: content hashes, NCCH RomFS hash and IVFC levels checked with ctrtool.')
    print('Unsigned ticket/TMD/NCCH signatures are expected in this homebrew package.')
