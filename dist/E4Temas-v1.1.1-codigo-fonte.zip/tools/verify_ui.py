"""Render actual C browser code and exercise batch/deletion flow with mocked console services."""
from pathlib import Path
import ctypes, subprocess, json
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
TC=ROOT.parent/'.toolchain/tcc/tcc.exe'
def function(text,name):
    start=text.index(name);start=text.rfind('static ',0,start)
    brace=text.index('{',start);depth=1;i=brace+1
    while depth:
        if text[i]=='{':depth+=1
        if text[i]=='}':depth-=1
        i+=1
    return text[start:i]
def main():
    out=ROOT/'build/validation/ui';out.mkdir(parents=True,exist_ok=True)
    source=(ROOT/'source/main.c').read_text(encoding='utf-8')
    common=r'''
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ui.h"
#include "tt.h"
#include "cleanup.h"
typedef unsigned u32;
#define GFX_TOP 0
#define GFX_BOTTOM 1
#define GFX_LEFT 0
#define JOURNAL "journal"
#define CANDIDATE "candidate"
#define KEY_A 1
#define KEY_B 2
#define KEY_X 4
#define KEY_DOWN 8
#define KEY_UP 16
#define KEY_L 32
#define KEY_R 64
static unsigned char top[400*240*3],bottom[320*240*3];
static unsigned char*gfxGetFramebuffer(int which,int side,void*a,void*b){return which?bottom:top;}
static void frame(void){}
static void gspWaitForVBlank(void){}
static int aptMainLoop(void){return 1;}
'''
    render=common+r'''
typedef struct {char label[256];char path[1024];int directory;} Choice;
static unsigned hidden_cias;
static Choice choices[6];static unsigned choice_count=6,queue_count=2;
static char current_dir[1024]="sdmc:/cias/temas";
static unsigned char previous_top[400*240*3];static int have_previous;
static int exists(const char*p){return 0;}
static int queue_index(const char*p){return strstr(p,"oceano")||strstr(p,"floresta")?1:-1;}
'''+function(source,'bottom_begin(')+'\n'+function(source,'draw_browser(')+r'''
__declspec(dllexport) void render_demo(int light,unsigned char*t,unsigned char*b){
 const char*names[]={"Pastas de temas","Favoritos","Tema oceano.cia","Tema espacial.cia","Tema floresta.cia","Pokemon - aniversario.cia"};unsigned i;
 for(i=0;i<6;i++){snprintf(choices[i].label,256,"%s",names[i]);snprintf(choices[i].path,1024,"sdmc:/cias/%s",names[i]);choices[i].directory=i<2;}
 ui_theme(light);draw_browser(0,0);memcpy(t,top,sizeof(top));memcpy(b,bottom,sizeof(bottom));
}
'''
    def compile(name,body):
        (out/(name+'.c')).write_text(body,encoding='utf-8')
        subprocess.run([str(TC),'-shared','-I'+str(ROOT/'include'),'-I'+str(ROOT/'source'),str(out/(name+'.c')),str(ROOT/'source/ui.c'),str(ROOT/'source/cleanup.c'),'-o',str(out/(name+'.dll'))],check=True)
        return ctypes.CDLL(str(out/(name+'.dll')))
    lib=compile('render',render);images=[]
    for light in [0,1]:
        top=ctypes.create_string_buffer(400*240*3);bottom=ctypes.create_string_buffer(320*240*3)
        lib.render_demo(light,top,bottom)
        def decode(buf,w):return Image.frombytes('RGB',(240,w),buf.raw,'raw','BGR').transpose(Image.Transpose.ROTATE_90)
        a,b=decode(top,400),decode(bottom,320)
        assert a.getpixel((10,70))==((160,92,231) if not light else (133,67,189))
        sheet=Image.new('RGB',(440,520),'#101215');sheet.paste(a,(20,10));sheet.paste(b,(60,270));sheet.save(out/('violeta.png' if not light else 'lilas.png'));images.append(sheet)
    board=Image.new('RGB',(900,520),'#101215');board.paste(images[0],(0,0));board.paste(images[1],(460,0));board.save(ROOT/'design/menu-implementado.png')
    progress=common+r'''
typedef unsigned long long u64;
static unsigned job_number=2,job_total=3,job_percent;static u64 last_progress;static int new_model=1;
static u64 osGetTime(void){return 1000;}
'''+function(source,'bottom_begin(')+'\n'+function(source,'progress_ui(')+r'''
__declspec(dllexport) void progress_demo(int light,unsigned char*b){ui_theme(light);job_percent=0;last_progress=0;progress_ui("Gravando catalogo no SD",80);memcpy(b,bottom,sizeof(bottom));}
'''
    progresslib=compile('progress',progress)
    board=Image.new('RGB',(680,260),'#101215')
    for light in [0,1]:
        buf=ctypes.create_string_buffer(320*240*3);progresslib.progress_demo(light,buf)
        panel=decode(buf,320);board.paste(panel,(10+340*light,10))
        assert panel.getpixel((20,110))==((160,92,231) if not light else (133,67,189))
        assert panel.getpixel((250,110))==((39,36,46) if not light else (228,212,242))
    board.save(ROOT/'design/progresso-1.1.1.png')
    lib.e4_can_delete_input.argtypes=[ctypes.c_char_p]
    for value,expected in [('sdmc:/cias/tema.cia',1),('sdmc:/cias/TEMA.CIA',1),('sdmc:/3ds/scl-temas/current.cia',0),('SDMC:/3DS/SCL-TEMAS/backup.cia',0),('sdmc:/3ds//scl-temas/current.cia',0),('sdmc:/cias/../3ds/scl-temas/current.cia',0),('sdmc:/Nintendo 3DS/x.cia',0),('sdmc:/cias/a.zip',0),('C:/x.cia',0),('sdmc:/cias/./a.cia',0)]:
        assert lib.e4_can_delete_input(value.encode())==expected,value
    batch=common+r'''
typedef struct {char path[1024];unsigned char hash[32];} QueueItem;
static QueueItem queue[100];static unsigned queue_count,pending_additions,job_total,job_number;static int batch_auto;
static int scenario,keys,deleted,installed,hashcalls;
static u32 key(void){keys++;if(keys==1&&scenario!=0)return KEY_X;return KEY_A;}
static u32 hidKeysHeld(void){return KEY_L|KEY_R;}
static int exists(const char*p){return scenario==5&&installed==2&&!strcmp(p,JOURNAL);}
static int installed_matches(const TTPackage*p,int a,char*e){return scenario!=6;}
static const char*select_base(void){return "base";}
static int tt_inspect_mock(const char*p,TTPackage*t,char*e){memset(t,0,sizeof(*t));t->count=2;return 0;}
#define tt_inspect tt_inspect_mock
static int hash_input(const char*p,unsigned char*h){hashcalls++;memset(h,0,32);if(scenario==3&&hashcalls==5)h[0]=1;return 1;}
static int add_theme(const char*p,int a,int b){if(scenario==2&&installed==1)return 0;installed++;return 1;}
static void message(const char*a,const char*b){}
static void logline(const char*a){}
static const char*filename(const char*p){return p;}
static void bottom_begin(const char*p){ui_surface(bottom,320);}
static void wrapped(int y,const char*s){}
static int remove_mock(const char*p){deleted++;return 0;}
#define remove remove_mock
'''+function(source,'review_queue(')+r'''
__declspec(dllexport) int test_batch(int mode){scenario=mode;keys=deleted=installed=hashcalls=0;queue_count=2;pending_additions=1;
 strcpy(queue[0].path,mode==4?"sdmc:/3ds/scl-temas/current.cia":"sdmc:/cias/a.cia");strcpy(queue[1].path,"sdmc:/cias/b.cia");ui_theme(0);review_queue();return deleted*100+installed*10+queue_count;
}
'''
    lib=compile('batch',batch)
    expected={0:20,1:220,2:11,3:120,4:120,5:20,6:2}
    results={str(mode):lib.test_batch(mode) for mode in expected}
    for mode,want in expected.items():assert results[str(mode)]==want,(mode,results[str(mode)],want)
    (out/'results.json').write_text(json.dumps({'cleanup_path_cases':10,'batch_cases':results,'rendered_palettes':2,'hardware_validation':False},indent=2),encoding='utf-8')
    print('Actual C UI rendered; 10 cleanup path cases and 7 batch flow scenarios passed.')
if __name__=='__main__':main()
