"""Compile the supplied logos to native sizes; do not regenerate the sand intro."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
ROOT=Path(__file__).resolve().parents[1]

def generate():
    folder=ROOT/'assets/new-logo'
    def fit(name,size):
        source=Image.open(folder/name).convert('RGBA')
        image=ImageOps.contain(source,size,Image.Resampling.LANCZOS)
        canvas=Image.new('RGBA',size)
        canvas.alpha_composite(image,((size[0]-image.width)//2,(size[1]-image.height)//2))
        return canvas
    banner=Image.new('RGBA',(256,128))
    banner.alpha_composite(fit('home.png',(120,120)),(4,4))
    ImageDraw.Draw(banner).text((130,48),'E4Temas',font=ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf',23),fill='#54058b')
    banner.save(ROOT/'assets/banner.png')
    icon=Image.new('RGBA',(48,48),'#181b1d');icon.alpha_composite(fit('home.png',(48,48)))
    icon.convert('RGB').save(ROOT/'assets/icon.png')
    font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14);glyphs=bytearray()
    for code in range(256):
        tile=Image.new('L',(8,16));ImageDraw.Draw(tile).text((0,-1),chr(code) if code>=32 else ' ',font=font,fill=255);glyphs.extend(tile.tobytes())
    def array(name,data):return 'static const unsigned char '+name+'[] = {\n'+','.join(str(x) for x in data)+'\n};\n'
    (ROOT/'source/ui_assets.h').write_text(array('e4_font',glyphs)+array('e4_logo_light',fit('light.png',(32,32)).tobytes())+array('e4_logo_dark',fit('dark.png',(32,32)).tobytes()),encoding='ascii')
    print('Supplied logos compiled; sand animation untouched.')

if __name__=='__main__':generate()
