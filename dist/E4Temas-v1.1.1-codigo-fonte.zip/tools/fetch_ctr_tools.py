from pathlib import Path
import concurrent.futures
import urllib.request
import zipfile
ROOT=Path(__file__).resolve().parents[1]
URLS={
    'bannertool':'https://github.com/Epicpkmn11/bannertool/releases/download/v1.2.2/bannertool.zip',
    'makerom':'https://github.com/3DSGuy/Project_CTR/releases/download/makerom-v0.19.0/makerom-v0.19.0-win_x86_64.zip',
    'ctrtool':'https://github.com/3DSGuy/Project_CTR/releases/download/ctrtool-v1.3.0/ctrtool-v1.3.0-win_x64.zip',
}
def fetch(item):
    name,url=item
    data=urllib.request.urlopen(url,timeout=30).read()
    path=ROOT/'.research'/(name+'.zip');path.write_bytes(data)
    dest=ROOT/'.toolchain'/name;dest.mkdir(exist_ok=True)
    with zipfile.ZipFile(path) as z:
        for entry in z.infolist():
            if not (dest/entry.filename).resolve().is_relative_to(dest.resolve()):
                raise RuntimeError('Unsafe archive')
        z.extractall(dest)
    return name,list(x.name for x in dest.iterdir())
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for value in pool.map(fetch,URLS.items()):print(value)
