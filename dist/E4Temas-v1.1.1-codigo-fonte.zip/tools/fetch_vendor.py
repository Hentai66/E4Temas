"""Pinned, permissively licensed PNG and DEFLATE implementations."""
from pathlib import Path
import hashlib
import urllib.request
ROOT=Path(__file__).resolve().parents[1]
FILES={
    'miniz_tdef.h':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz_tdef.h',
    'miniz_zip.h':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz_zip.h',
    'stb_image.h':'https://raw.githubusercontent.com/nothings/stb/f0569113c93ad095470c54bf34a17b36646bbbb5/stb_image.h',
    'miniz_tinfl.c':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz_tinfl.c',
    'miniz_tinfl.h':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz_tinfl.h',
    'miniz_common.h':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz_common.h',
    'miniz.h':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/miniz.h',
    'miniz-LICENSE':'https://raw.githubusercontent.com/richgel999/miniz/3.0.2/LICENSE',
}
if __name__=='__main__':
    folder=ROOT/'vendor';folder.mkdir(exist_ok=True)
    for name,url in FILES.items():
        data=urllib.request.urlopen(url,timeout=20).read()
        (folder/name).write_bytes(data)
        print(name,len(data),hashlib.sha256(data).hexdigest())
