"""Verify transparency in the actual compressed CBMD, not only the source PNG."""
from pathlib import Path
import struct,json
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def decode_lz11(data):
    assert data[0]==0x11
    size=int.from_bytes(data[1:4],'little');i=4
    if not size:size=struct.unpack_from('<I',data,4)[0];i=8
    out=bytearray()
    while len(out)<size:
        flags=data[i];i+=1
        for bit in range(8):
            if len(out)>=size:break
            if not flags&(128>>bit):out.append(data[i]);i+=1;continue
            a=data[i];i+=1;v=a>>4
            if v==0:
                b,c=data[i:i+2];i+=2;length=((a&15)<<4)+(b>>4)+17;distance=((b&15)<<8)+c+1
            elif v==1:
                b,c,d=data[i:i+3];i+=3;length=((a&15)<<12)+(b<<4)+(c>>4)+273;distance=((c&15)<<8)+d+1
            else:
                b=data[i];i+=1;length=v+1;distance=((a&15)<<8)+b+1
            assert 0<distance<=len(out) and len(out)+length<=size
            for _ in range(length):out.append(out[-distance])
    return bytes(out)
def verify():
    data=(ROOT/'build/banner.bnr').read_bytes();assert data[:4]==b'CBMD'
    off=struct.unpack_from('<I',data,8)[0];cgfx=decode_lz11(data[off:]);assert cgfx[:4]==b'CGFX'
    # bannertool 1.2.2 uses a 0x1580-byte CGFX template and a 256x128 RGBA4444 texture.
    assert len(cgfx)==0x1580+256*128*2
    image=Image.open(ROOT/'assets/banner.png').convert('RGBA');expected=bytearray()
    order=[0,1,8,9,2,3,10,11,16,17,24,25,18,19,26,27,4,5,12,13,6,7,14,15,20,21,28,29,22,23,30,31,32,33,40,41,34,35,42,43,48,49,56,57,50,51,58,59,36,37,44,45,38,39,46,47,52,53,60,61,54,55,62,63]
    alphas=[]
    for y in range(0,128,8):
        for x in range(0,256,8):
            for k in order:
                r,g,b,a=image.getpixel((x+(k&7),y+(k>>3)))
                expected.extend(struct.pack('<H',((r>>4)<<12)|((g>>4)<<8)|((b>>4)<<4)|(a>>4)));alphas.append(a>>4)
    assert cgfx[0x1580:]==expected
    assert alphas.count(0)>20000 and alphas.count(15)>1000
    report={'rgba4444_matches_png':True,'transparent_pixels':alphas.count(0),'opaque_pixels':alphas.count(15),'hardware_display_verified':False}
    (ROOT/'build/validation/banner-alpha.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(report)
if __name__=='__main__':verify()
