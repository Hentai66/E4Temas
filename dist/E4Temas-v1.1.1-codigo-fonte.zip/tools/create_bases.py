"""Create experimental, original empty theme catalogs using public format metadata.

No commercial themes, console keys or HTT binaries are included. makerom uses its
test-key/production-certificate mode (-target t). Hardware validation is pending.
"""
from pathlib import Path
import argparse
import ctypes
import os
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from reference import ncch

REGIONS={
    'JPN': (0,0x8200, [('ja',0)]),
    'USA': (1,0x8F00, [('en',1),('fr',2),('es',5),('pt',9)]),
    'EUR': (2,0x9800, [('en',1),('fr',2),('de',3),('it',4),('es',5),('nl',8),('pt',9),('ru',10)]),
}

def create(makerom, variation=9):
    if not 1<=variation<=255:
        raise ValueError('Use a separate DLC variation from 1 to 255')
    out=ROOT/'build'/'bases';out.mkdir(parents=True,exist_ok=True)
    lib=ctypes.CDLL(str(ROOT/'build'/'temas3ds.dll')) if os.name=='nt' else None
    for region,(code,low,languages) in REGIONS.items():
        metadata=bytearray(0x34+4*len(languages))
        struct.pack_into('<5I',metadata,0,1,0,1,0x300030,0xDEADBEEF)
        metadata[0x14:0x30]=b'\xff'*(0x30-0x14)
        struct.pack_into('<HH',metadata,0x14+code*4,code,languages[0][1])
        struct.pack_into('<I',metadata,0x30,len(languages))
        files={'MetaDataContentHeader.bin':bytes(metadata)}
        for i,(language,lang_code) in enumerate(languages):
            struct.pack_into('<HH',metadata,0x34+4*i,code,lang_code)
            files[f'ContentInfoArchive_{region}_{language}.bin']=struct.pack('<II',1,0)+bytes(200)
        files['MetaDataContentHeader.bin']=bytes(metadata)
        title=0x0004008C00000000 | low | variation
        cfa=out/(region+'.cfa');cfa.write_bytes(ncch(files,title,index=0))
        cia=out/(region+'.cia')
        subprocess.run([str(makerom),'-f','cia','-dlc','-target','t','-ignoresign',
                        '-content',str(cfa)+':0:0','-ver','1','-o',str(cia)],check=True)
        if lib:
            error=ctypes.create_string_buffer(256)
            fixed=out/(region+'-native.cia')
            if fixed.exists():fixed.unlink()
            if lib.tt_repair(os.fsencode(cia),os.fsencode(fixed),error):
                raise RuntimeError(error.value.decode())
            fixed.replace(cia)
            if lib.tt_verify(os.fsencode(cia),error):
                raise RuntimeError(error.value.decode())
        print(region,hex(title),cia.stat().st_size)
    return out

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--makerom',type=Path,default=ROOT/'.toolchain'/'makerom'/'makerom.exe')
    parser.add_argument('--variation',type=lambda s:int(s,0),default=9)
    args=parser.parse_args();create(args.makerom,args.variation)
