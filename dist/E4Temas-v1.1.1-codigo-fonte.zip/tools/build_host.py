"""Build the SAME portable C core used on 3DS, for desktop verification."""
from pathlib import Path
import argparse
import hashlib
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def build(compiler=None):
    target = ROOT / 'build'
    target.mkdir(exist_ok=True)
    if compiler is None:
        compiler = ROOT / '.toolchain' / 'tcc' / 'tcc.exe'
        if not compiler.exists():
            archive = ROOT / '.research' / 'tinycc.zip'
            if not archive.exists():
                raise SystemExit('Informe --cc com o caminho de um compilador C (TinyCC no Windows).')
            with zipfile.ZipFile(archive) as z:
                for entry in z.infolist():
                    destination = (ROOT / '.toolchain' / entry.filename).resolve()
                    if not destination.is_relative_to((ROOT / '.toolchain').resolve()):
                        raise SystemExit('Archive path traversal')
                z.extractall(ROOT / '.toolchain')
    compiler = str(compiler)
    dll = target / 'temas3ds.dll'
    command = [compiler, '-shared', '-Wall', '-Iinclude', '-Isource', '-Ivendor',
               '-DMINIZ_NO_ARCHIVE_APIS','-DMINIZ_NO_DEFLATE_APIS','-DMINIZ_NO_ZLIB_APIS',
               'source/format.c', 'source/sha256.c', 'source/import.c', 'vendor/miniz_tinfl.c', '-o', str(dll)]
    subprocess.run(command, cwd=ROOT, check=True)
    print(f'{dll.name} SHA256 {hashlib.sha256(dll.read_bytes()).hexdigest()}')
    return dll

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cc')
    build(parser.parse_args().cc)
