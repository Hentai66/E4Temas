# E4Temas 1.1.1 — desempenho e progresso

- New 3DS/XL/2DS XL: detecção por APT e osSetSpeedupEnable(true). Old mantém o modo normal. Compilação ARMv6K comum, sem exigir instruções exclusivas do New.
- Gravação AM em blocos de 1 MiB no New e 256 KiB no Old, com fallback de 64 KiB se faltar memória. Tela limitada a 10 atualizações/s, sem esperar um quadro a cada bloco.
- Verificação SHA e NCCH usa a mesma leitura do conteúdo, eliminando uma passagem completa pelo SD. CRC32 da extração ZIP usa tabela, mantendo a checagem de integridade.
- Continua processando UM tema por vez. Para cada um, reconstrói e instala o catálogo cumulativo. Portanto, coleções grandes ainda custam mais; esta versão não implementa instalação paralela nem uma única reconstrução para toda a fila.
- Barra da fila 0–100%, tema atual/total, extraídos, instalados e etapa. Percentual ponderado por etapas (verificar, extrair, montar, validar, gravar, finalizar); não estima tempo restante. Gravação usa bytes reais. Só mostra 100% após a verificação pós-instalação e finalização do diário. Pré-verificação da fila ocorre antes da barra. Operações indivisíveis podem pausar o avanço.
- Filtro rápido lê CIA/RomFS/ZIP para procurar um body_LZ.bin único e limitado, sem extrair no navegador. CIAs incompatíveis ficam ocultas, com contador. O filtro não autentica a origem e não substitui a validação completa; um arquivo disfarçado pode aparecer e ser rejeitado na importação.
- A CIA de origem NUNCA é enviada ao AM nem executada. Somente o catálogo de temas gerado e validado é instalado. Jogos comuns são ocultados/rejeitados; um executável com dados de tema válidos pode fornecer esses dados, mas seu código continua sendo ignorado.
- Exclusão opcional continua somente após sucesso de toda a fila e conferência dos arquivos. Backups e recuperação preservados.

Referências consultadas: https://github.com/Universal-Team/Universal-Updater/blob/master/source/main.cpp (speedup) e https://github.com/Universal-Team/Universal-Updater/blob/master/source/utils/cia.cpp (I/O em blocos). Implementação própria; sem copiar o instalador genérico. Não há benchmark comparativo ou comprovação de saturação do hardware. A extração específica de temas continua usando miniz.

Validação: 35 testes do núcleo, 10 casos de proteção de caminhos, 7 cenários de fila simulados; renderização C da barra nas duas paletas; verificação CIA/3DSX e hashes com ctrtool. Hardware New/Old e ganho de velocidade ainda precisam de medição real.
