# Validação de hardware pendente — E4Temas

A versão 0.1.1 abriu, mas não exibiu os temas no seletor. Teste agora o reparo
da 0.1.2 descrito em [CATALOG_FIX.md](CATALOG_FIX.md).

Nenhum item abaixo foi executado nesta sessão. A compilação ARM e os testes no
computador não substituem esses resultados.

- [ ] Abrir a versão 3DSX em Old 3DS e New 3DS com Luma 13.4.
- [ ] Instalar a CIA do aplicativo e verificar ícone, banner e inicialização.
- [ ] Confirmar a leitura de uma CIA real do instalador hShop sem executá-la.
- [ ] Confirmar que a variação 09 é enumerada pelo HOME Menu em JPN/USA/EUR.
- [ ] Adicionar A, reiniciar, verificar A em Trocar tema.
- [ ] Adicionar B e C; confirmar A+B+C na lista, com troca em ambas as direções.
- [ ] Confirmar fundos, animações, música e efeitos sonoros dos três temas.
- [ ] Confirmar que temas comprados anteriormente continuam listados e utilizáveis.
- [ ] Usar os temas misturados em Alternar favoritos; conferir limite de dez.
- [ ] Confirmar a persistência após reiniciar e após trocar para um tema padrão.
- [ ] Confirmar comportamento após abrir a Theme Shop, sem pressupor a correção do HTT.
- [ ] Testar o bloqueio diante de uma base desatualizada ou título FE já existente.
- [ ] Validar espaço livre, heap/stack e tempos de geração em Old 3DS.
- [ ] Validar os dois estados reconhecidos por R e o bloqueio de estados ambíguos.
- [ ] Validar versões posteriores do Luma separadamente.

Não provocar desligamento durante instalação em um console de uso normal. Testes
de falha de energia exigem um ambiente com recuperação previamente verificada.
