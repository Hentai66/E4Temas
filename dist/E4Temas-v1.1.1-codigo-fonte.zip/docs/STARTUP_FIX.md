# E4Temas 0.1.1 — correção do perfil e diagnóstico de abertura

O usuário relatou ErrDisp “The SD card was removed” ao abrir a CIA E4Temas 0.1.
O console voltou ao normal após reiniciar; a reabertura da versão anterior não
foi testada. A causa exata da ocorrência ainda não foi confirmada.

## Alterações verificadas

- Permissões DirectSdmc e DirectSdmcWrite declaradas explicitamente.
- Serviços am:net e am:app incluídos para a instalação e consulta de conteúdos.
- Removido o preset makerom `-desc app:4`, que sobrescrevia a lista de serviços.
  O RSF agora declara o perfil de CPU, kernel e dependências explicitamente.
- Logo Homebrew incluído na ExeFS, seguindo o empacotamento de homebrew conhecido.
- Title ID preservado: `000400000F5C1E00`. Versão interna da CIA: 1025 (anterior: 1024),
  permitindo atualizar o aplicativo existente.
- Diagnóstico de SD e montagem do RomFS com interrupção se falharem.
- Registro das etapas de abertura, quando for possível gravar no SD.

Esses defeitos do perfil foram corrigidos nos arquivos gerados. Não está provado
que algum deles tenha causado especificamente a mensagem da foto. Nenhuma nova
versão foi executada em hardware nesta sessão. O HTT não foi obtido/destrinchado;
a comparação do perfil usou fontes abertas do Anemone3DS, makerom e Luma.

## Como testar a abertura

1. Instale a nova CIA por cima da anterior com seu instalador habitual.
   Não é necessário excluir o aplicativo ou sua pasta de dados primeiro.
2. Abra o aplicativo e veja se chega ao navegador de arquivos; saia com START.
   Neste primeiro teste, não selecione nem instale um tema.
3. Se reaparecer o erro, reinicie como indicado na tela e informe o resultado.
   Confira, se existir, `/3ds/scl-temas/boot-e4temas.log` no cartão.
   O registro `version=0.1.1 main.enter` identifica a nova execução;
   `ui.ready` indica que o navegador foi alcançado. Os registros são acumulados.
4. A versão 3DSX incluída pode ser aberta no Homebrew Launcher para comparar
   o caminho de inicialização, também sem instalar temas.

A ausência de log não prova defeito físico no cartão: a falha pode acontecer
antes de main ou antes de ser possível gravar. Não formate o SD nem apague
extdata, tickets ou a pasta `/3ds/scl-temas/` para esse teste. As duas marcas
continuam compartilhando essa pasta e o catálogo cumulativo existente.

O funcionamento dos temas no seletor nativo e a preservação junto aos temas
comprados ainda exigem validação real. Os testes estruturais preservam os
conteúdos anteriores, mas não demonstram o comportamento do HOME Menu.

## Referências técnicas

- https://github.com/astronautlevel2/Anemone3DS/blob/master/meta/app.rsf
- https://github.com/astronautlevel2/Anemone3DS/blob/master/Makefile
- https://github.com/3DSGuy/Project_CTR/blob/makerom-v0.19.0/makerom/src/accessdesc.c
- https://github.com/LumaTeam/Luma3DS/blob/v13.4/sysmodules/rosalina/source/errdisp.c
