# E4Temas 0.1.2 — catálogo nativo e reparo

## Resultado observado

O usuário confirmou que a CIA 0.1.1 abre normalmente. A instalação de um tema
foi concluída duas vezes e o console reiniciado, mas o tema não apareceu em
Trocar tema. A versão 0.1.2 corrige divergências concretas em relação ao HTT;
a exibição no console ainda precisa de confirmação após esta entrega.

## Para quem já instalou temas na 0.1.1

1. Instale `e4temas.cia` desta entrega. A versão interna é 1026; a anterior era
   1025. O aplicativo conserva seu Title ID e a pasta de trabalho.
2. Abra o aplicativo e pressione **L — reparar catálogo existente**.
3. Confirme com **L + R + A**. O reparo usa `current.cia`, contendo os temas já
   adicionados, e não precisa da CIA original do tema.
4. Saia, reinicie o console e abra **Trocar tema**. Se o tema estiver listado,
   selecione-o nesse menu. A instalação do pacote não aplica um tema automaticamente.
5. Depois, adicione novos temas normalmente com A. A coleção permanece cumulativa.

Se disser que `candidate.cia` já existe e não houver recuperação pendente,
SELECT permite descartar somente esse candidato não instalado; depois use L.
Se faltar `current.cia`, não é possível recuperar a coleção só a partir do log:
use a CIA original do tema para uma nova adição ou preserve seus backups.

## Alterações

- Variação de título **09**, igual à usada pelo HTT 1.7.0 Xmas, em vez de FE.
- Conteúdo de controle com ExeFS e SMDH originais do projeto. Antes havia somente
  RomFS. Os próprios comandos de construção do HTT incluem esse SMDH.
- Contagem de ContentInfoArchive exclui o registro dummy inicial, conforme os
  pacotes de referência extraídos do HTT: USA 114 + dummy, EUR 106 + dummy,
  JPN 269 + dummy. A leitura reconhece também a contagem antiga para repará-la.
- RomFS alinhado a 4096 bytes e cabeçalhos CFA coerentes com makerom, inclusive
  versão NCCH de conteúdo de dados. Os hashes são recalculados.
- Idioma japonês corrigido de `jp` para `ja` no nome do arquivo.
- Reparo preserva índices, nomes, ícones, body_LZ.bin, música e demais arquivos
  dos temas. Ao migrar FE para 09, cabeçalhos e encapsulamento NCCH mudam;
  os arquivos de conteúdo permanecem iguais.
- O catálogo FE antigo e seu backup não são excluídos. O aplicativo passa a
  usar o catálogo 09 após confirmar a instalação. FE não entra novamente na
  contagem da coleção 09, evitando contar a cópia antiga duas vezes.
- Se o destino 09 já existir durante a migração, a operação é bloqueada. Isso
  evita substituir uma coleção de outro gerenciador. Não exclua essa coleção.
- O reparo usa o mesmo diário e backups da instalação. Se interrompido, R tenta
  finalizar um candidato confirmado pelo sistema; estados ambíguos ficam bloqueados.

## Verificação

32 testes do núcleo por variante passaram, incluindo migração FE → 09, reparo
repetido, preservação dos conteúdos, 100 temas, adição posterior ao reparo,
recusa de título primário e de destino já existente no sistema de arquivos.
A proteção contra um título 09 já instalado usa consultas AM no console;
ainda não houve teste dessa situação em hardware.

ctrtool verificou os hashes do aplicativo e dos pacotes sintéticos. Os testes
não executam o HOME Menu. Não se afirma que todas as melhorias do HTT foram
reproduzidas ou que a nova versão já foi validada no console.

O HTT foi obtido pelo link do autor e seus recursos, parâmetros RSF e comandos
foram inspecionados estaticamente. Nenhum tema comercial, SMDH Nintendo, binário
ou código de interface do HTT foi incorporado à entrega. Metadados e código
novos foram implementados neste projeto a partir da estrutura observada.

## Se continuar sem aparecer

Preserve `/3ds/scl-temas/current.cia`, `log.txt`, `pending.txt` (se existir) e
os backups. O log registra os títulos de origem/destino e a quantidade de temas.
Não formate o SD, não apague extdata e não reinstale repetidamente o mesmo tema.

Referências: [publicação do autor do HTT](https://gbatemp.net/threads/release-howling-theme-tool-create-your-own-cia-theme-packages-with-custom-and-official-themes.401081/),
[explicação de redunka sobre a variação 09](https://gbatemp.net/threads/korean-3ds-firmware-could-add-themes-in-official-home-menu-theme-changer.667752/).
Detalhes numéricos da comparação: `CATALOG_COMPARISON.json`.
