import ctypes
import hashlib
import io
import os
from pathlib import Path
import random
import struct
import tempfile
import unittest
import zipfile
import zlib
from reference import cia_fixture, read_cia, body, TITLE

ROOT = Path(__file__).resolve().parents[1]
LIB = ctypes.CDLL(str(ROOT/'build'/'temas3ds.dll'))
LIB.tt_verify.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
LIB.tt_add.argtypes = [ctypes.c_char_p]*3 + [ctypes.c_void_p]
LIB.tt_repair.argtypes = [ctypes.c_char_p]*3
LIB.tt_sha256.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]

def path(p):
    return os.fsencode(p)

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.base = self.root/'base.cia'
        self.control, self.old = cia_fixture(self.base)
        self.theme = self.root/'Novo tema'
        self.theme.mkdir()
        (self.theme/'body_LZ.bin').write_bytes(body(77))
        (self.theme/'name.txt').write_text('Pokémon: teste', encoding='utf-8')
        (self.theme/'icon.icn').write_bytes(bytes(range(256))*18)
        self.dest = self.root/'candidate.cia'
        self.error = ctypes.create_string_buffer(256)

    def tearDown(self):
        self.tmp.cleanup()

    def add(self, base=None, folder=None, dest=None):
        return LIB.tt_add(path(base or self.base), path(folder or self.theme), path(dest or self.dest), self.error)

    def test_game_cia_rejected_without_installing(self):
        game=self.root/'game.cia'
        cia_fixture(game,title=0x0004000001111100,count=0,control_override={'game.bin':b'game data'})
        self.assertEqual(LIB.tt_is_theme_cia(path(game)),0)
        self.assertNotEqual(self.add(folder=game),0)
        self.assertFalse(self.dest.exists())

    def test_probe_is_not_full_validation(self):
        zipped=io.BytesIO()
        with zipfile.ZipFile(zipped,'w') as z:z.writestr('body_LZ.bin',b'not a theme')
        fake=self.root/'fake.cia'
        cia_fixture(fake,title=0x0004000001111100,count=0,control_override={'theme.zip':zipped.getvalue()})
        self.assertEqual(LIB.tt_is_theme_cia(path(fake)),1)
        self.assertNotEqual(self.add(folder=fake),0)
        self.assertFalse(self.dest.exists())

    def test_progress_stages_are_monotonic(self):
        events=[]
        cbtype=ctypes.CFUNCTYPE(None,ctypes.c_char_p,ctypes.c_uint)
        callback=cbtype(lambda stage,percent:events.append((stage.decode(),percent)))
        LIB.tt_set_progress.argtypes=[cbtype]
        LIB.tt_set_progress(callback)
        try:self.assertEqual(self.add(),0,self.error.value)
        finally:LIB.tt_set_progress(cbtype())
        values=[p for _,p in events]
        self.assertEqual(values,sorted(values))
        self.assertEqual(values[0],0)
        self.assertEqual(values[-1],65)
        self.assertTrue(any('Extraindo' in stage for stage,_ in events))

    def test_sha_vectors(self):
        for value in [b'', b'abc', b'x'*55, b'x'*56, b'x'*64, b'x'*1000000]:
            out = ctypes.create_string_buffer(32)
            LIB.tt_sha256(value, len(value), out)
            self.assertEqual(out.raw, hashlib.sha256(value).digest())


    def assert_native_control(self, contents, themes):
        raw,files=contents[0]
        self.assertEqual(struct.unpack_from('<H',raw,0x112)[0],0)
        self.assertEqual(struct.unpack_from('<I',raw,0x1B0)[0]*512 % 4096,0)
        exoff,exsize=struct.unpack_from('<II',raw,0x1A0)
        self.assertEqual(exsize,0x1D)
        ex=raw[exoff*512:(exoff+exsize)*512]
        self.assertEqual(ex[:8],b'icon'+bytes(4))
        self.assertEqual(ex[512:516],b'SMDH')
        self.assertEqual(hashlib.sha256(ex[:512]).digest(),raw[0x1C0:0x1E0])
        self.assertEqual(hashlib.sha256(ex[512:512+0x36C0]).digest(),ex[0x1E0:0x200])
        for name,data in files.items():
            if name.startswith('ContentInfoArchive_'):
                # HTT reference packages: 114 real USA entries + one dummy,
                # header count 114; JPN 269 + dummy, count 269.
                self.assertEqual(struct.unpack_from('<I',data,4)[0],themes)
                self.assertEqual(len(data),8+200*(themes+1))
                self.assertEqual(data[8+192:8+200],bytes(8))

    def test_native_control_has_smdh_alignment_and_count_excludes_dummy(self):
        self.assertEqual(self.add(),0,self.error.value)
        _,contents=read_cia(self.dest)
        self.assert_native_control(contents,2)
        self.assertEqual(struct.unpack_from('<I',contents[2][0],0x1B0)[0]*512%4096,0)

    def test_repair_migrates_fe_preserving_every_theme_payload(self):
        cia_fixture(self.base,title=0x0004008C00008FFE,count=3)
        original=self.base.read_bytes();_,before=read_cia(self.base)
        self.assertEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0,self.error.value)
        self.assertEqual(self.base.read_bytes(),original)
        _,after=read_cia(self.dest);self.assert_native_control(after,3)
        self.assertEqual(set(before),set(after))
        for index in after:
            self.assertEqual(struct.unpack_from('<Q',after[index][0],0x118)[0],0x0004008C00008F09)
            if index:self.assertEqual(before[index][1],after[index][1])
        next_cia=self.root/'next.cia'
        self.assertEqual(self.add(base=self.dest,dest=next_cia),0,self.error.value)
        _,added=read_cia(next_cia);self.assert_native_control(added,4)
        for index in (1,2,3):self.assertEqual(added[index][0],after[index][0])

    def test_repair_09_retains_identity_and_allows_repeated_repair(self):
        cia_fixture(self.base,title=0x0004008C00008F09,count=2)
        self.assertEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0,self.error.value)
        other=self.root/'second.cia'
        self.assertEqual(LIB.tt_repair(path(self.dest),path(other),self.error),0,self.error.value)
        _,contents=read_cia(other);self.assert_native_control(contents,2)

    def test_repair_primary_title_refused_without_output(self):
        cia_fixture(self.base,title=0x0004008C00008F00)
        self.assertNotEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0)
        self.assertFalse(self.dest.exists())

    def test_repair_japanese_legacy_language_filename(self):
        control=dict(self.control)
        cat=control.pop('ContentInfoArchive_USA_en.bin');control.pop('ContentInfoArchive_USA_pt.bin')
        control['ContentInfoArchive_JPN_jp.bin']=cat
        meta=bytearray(control['MetaDataContentHeader.bin']);struct.pack_into('<I',meta,0x30,1)
        control['MetaDataContentHeader.bin']=bytes(meta)
        cia_fixture(self.base,title=0x0004008C000082FE,control_override=control)
        self.assertEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0,self.error.value)
        _,contents=read_cia(self.dest)
        self.assertIn('ContentInfoArchive_JPN_ja.bin',contents[0][1])
        self.assertNotIn('ContentInfoArchive_JPN_jp.bin',contents[0][1])

    def test_repair_does_not_overwrite_destination(self):
        cia_fixture(self.base,title=0x0004008C00008FFE)
        self.dest.write_bytes(b'keep')
        self.assertNotEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0)
        self.assertEqual(self.dest.read_bytes(),b'keep')

    def test_repair_full_hundred_theme_catalog(self):
        cia_fixture(self.base,title=0x0004008C00008FFE,count=100)
        self.assertEqual(LIB.tt_repair(path(self.base),path(self.dest),self.error),0,self.error.value)
        _,contents=read_cia(self.dest);self.assert_native_control(contents,100)

    def test_catalog_invalid_entry_count_rejected(self):
        control=dict(self.control);cat=bytearray(control['ContentInfoArchive_USA_en.bin'])
        struct.pack_into('<I',cat,4,500);control['ContentInfoArchive_USA_en.bin']=bytes(cat)
        cia_fixture(self.base,control_override=control)
        self.assertNotEqual(self.add(),0)
        self.assertFalse(self.dest.exists())

    def test_add_preserves_content_and_native_catalog(self):
        original = self.base.read_bytes()
        self.assertEqual(self.add(), 0, self.error.value)
        self.assertEqual(self.base.read_bytes(), original)
        _, entries = read_cia(self.dest)
        self.assertEqual(set(entries), {0, 1, 2})
        self.assertEqual(entries[1][0], self.old[1][1])
        control = entries[0][1]
        for lang in ('en','pt'):
            cat = control[f'ContentInfoArchive_USA_{lang}.bin']
            self.assertEqual(cat[8:408], self.control[f'ContentInfoArchive_USA_{lang}.bin'][8:])
            self.assertEqual(cat[408:408+len('Pokémon: teste'.encode())], 'Pokémon: teste'.encode())
        self.assertEqual(control['icons/1.icn'], self.control['icons/1.icn'])
        self.assertEqual(control['icons/2.icn'], (self.theme/'icon.icn').read_bytes())
        self.assertEqual(entries[2][1]['body_LZ.bin'], (self.theme/'body_LZ.bin').read_bytes())
        self.assertEqual(LIB.tt_verify(path(self.dest), self.error), 0, self.error.value)

    def test_second_add_is_cumulative(self):
        self.assertEqual(self.add(), 0, self.error.value)
        (self.theme/'body_LZ.bin').write_bytes(body(89))
        second = self.root/'second.cia'
        self.assertEqual(self.add(base=self.dest,dest=second), 0, self.error.value)
        _, first = read_cia(self.dest)
        _, last = read_cia(second)
        self.assertEqual(set(last), {0,1,2,3})
        for index in (1,2):
            self.assertEqual(first[index][0], last[index][0])

    def test_ten_successive_additions_from_empty_catalog_preserve_all_previous(self):
        cia_fixture(self.base,count=0)
        base=self.base
        previous={}
        for number in range(1,11):
            (self.theme/'body_LZ.bin').write_bytes(body(number+50))
            destination=self.root/f'collection-{number}.cia'
            self.assertEqual(self.add(base=base,dest=destination),0,self.error.value)
            _,contents=read_cia(destination)
            self.assertEqual(set(contents),set(range(number+1)))
            for index,data in previous.items():
                self.assertEqual(contents[index][0],data)
            previous={index:content[0] for index,content in contents.items() if index}
            base=destination

    def test_automatic_name_from_smdh_no_manual_metadata(self):
        (self.theme/'name.txt').unlink()
        smdh=bytearray(0x36C0)
        smdh[:4]=b'SMDH'
        name='Pokémon oficial'
        encoded=name.encode('utf-16le')
        smdh[0x208:0x208+len(encoded)]=encoded
        (self.theme/'info.smdh').write_bytes(smdh)
        self.assertEqual(self.add(),0,self.error.value)
        _,contents=read_cia(self.dest)
        catalog=contents[0][1]['ContentInfoArchive_USA_en.bin']
        self.assertEqual(catalog[408:408+len(name.encode())],name.encode())

    def test_duplicate_generated_theme_rejected(self):
        self.assertEqual(self.add(), 0, self.error.value)
        self.assertNotEqual(self.add(base=self.dest,dest=self.root/'duplicate.cia'), 0)
        self.assertIn(b'ja esta', self.error.value)

    def test_zip_stored_and_deflated(self):
        for method in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):
            archive=self.root/f'theme-{method}.zip'
            with zipfile.ZipFile(archive,'w',compression=method) as z:
                for file in self.theme.iterdir():
                    z.write(file,'pasta/'+file.name)
            dest=self.root/f'zip-{method}.cia'
            self.assertEqual(self.add(folder=archive,dest=dest),0,self.error.value)
            _,contents=read_cia(dest)
            self.assertEqual(contents[2][1]['body_LZ.bin'],(self.theme/'body_LZ.bin').read_bytes())

    def test_plaintext_installer_cia_imported_without_execution(self):
        zipped=io.BytesIO()
        with zipfile.ZipFile(zipped,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for file in self.theme.iterdir():
                z.writestr(file.name,file.read_bytes())
        installer=self.root/'theme-installer.cia'
        cia_fixture(installer,title=0x0004000001111100,count=0,control_override={'theme.zip':zipped.getvalue()})
        self.assertEqual(LIB.tt_is_theme_cia(path(installer)),1)
        original=installer.read_bytes()
        self.assertEqual(self.add(folder=installer),0,self.error.value)
        self.assertEqual(installer.read_bytes(),original)
        _,contents=read_cia(self.dest)
        self.assertEqual(contents[2][1]['body_LZ.bin'],(self.theme/'body_LZ.bin').read_bytes())

    def test_encrypted_installer_cia_rejected(self):
        zipped=io.BytesIO()
        with zipfile.ZipFile(zipped,'w') as z:z.writestr('body_LZ.bin',body(77))
        installer=self.root/'encrypted.cia'
        cia_fixture(installer,title=0x0004000001111100,count=0,control_override={'theme.zip':zipped.getvalue()})
        data=bytearray(installer.read_bytes())
        # One-content fixture: locate main NCCH from section sizes.
        tik=((0x2040+struct.unpack_from('<I',data,8)[0]+63)//64)*64
        tmd=((tik+struct.unpack_from('<I',data,12)[0]+63)//64)*64
        main=((tmd+struct.unpack_from('<I',data,16)[0]+63)//64)*64
        data[main+0x18F]=0
        installer.write_bytes(data)
        self.assertEqual(LIB.tt_is_theme_cia(path(installer)),0)
        self.assertNotEqual(self.add(folder=installer),0)
        self.assertFalse(self.dest.exists())

    def test_zip_ambiguous_theme_roots_rejected(self):
        archive=self.root/'ambiguous.zip'
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr('one/body_LZ.bin',body(15))
            z.writestr('two/body_LZ.bin',body(16))
        self.assertNotEqual(self.add(folder=archive),0)

    def test_zip_crc_mismatch_rejected(self):
        archive=self.root/'broken.zip'
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr('body_LZ.bin',body(15))
        data=bytearray(archive.read_bytes())
        data[30+len('body_LZ.bin')+8]^=1
        archive.write_bytes(data)
        self.assertNotEqual(self.add(folder=archive),0)

    def test_zip_path_traversal_rejected(self):
        archive=self.root/'paths.zip'
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr('../body_LZ.bin',body(15))
        self.assertNotEqual(self.add(folder=archive),0)
        self.assertFalse(self.dest.exists())

    def test_zip_expansion_limit_rejected(self):
        archive=self.root/'large.zip'
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('body_LZ.bin',b'0'*(0x150000+1))
        self.assertNotEqual(self.add(folder=archive),0)

    def test_icon_png_rgb565_tiling(self):
        def chunk(kind,payload):
            return struct.pack('>I',len(payload))+kind+payload+struct.pack('>I',zlib.crc32(kind+payload))
        raw=b''.join(b'\0'+b''.join(bytes((x*5,y*5,0,255)) for x in range(48)) for y in range(48))
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>2I5B',48,48,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
        (self.theme/'icon.icn').unlink()
        (self.theme/'icon.png').write_bytes(png)
        self.assertEqual(self.add(),0,self.error.value)
        _,contents=read_cia(self.dest)
        icon=contents[0][1]['icons/2.icn']
        for x,y in [(0,0),(1,2),(8,9),(47,47)]:
            m=sum(((x>>b)&1)<<(2*b) | ((y>>b)&1)<<(2*b+1) for b in range(3))
            offset=(((y//8)*6+x//8)*64+m)*2
            expected=((x*5>>3)<<11)|((y*5>>2)<<5)
            self.assertEqual(struct.unpack_from('<H',icon,offset)[0],expected)

    def test_music_preserved_verbatim(self):
        (self.theme/'body_LZ.bin').write_bytes(body(77,music=True))
        music=bytearray(0x40)
        music[:4]=b'CSTM'
        struct.pack_into('<H',music,4,0xFEFF)
        struct.pack_into('<I',music,12,len(music))
        (self.theme/'bgm.bcstm').write_bytes(music)
        self.assertEqual(self.add(),0,self.error.value)
        _,contents=read_cia(self.dest)
        self.assertEqual(contents[2][1]['bgm.bcstm'],music)

    def test_unknown_ticket_layout_rejected_without_output(self):
        data=bytearray(self.base.read_bytes())
        tikoff=((0x2040+0xA00+63)//64)*64
        data[tikoff+0x2A4]^=1
        self.base.write_bytes(data)
        self.assertNotEqual(self.add(),0)
        self.assertFalse(self.dest.exists())

    def test_output_not_overwritten(self):
        self.dest.write_bytes(b'KEEP')
        self.assertNotEqual(self.add(), 0)
        self.assertEqual(self.dest.read_bytes(), b'KEEP')

    def test_corrupt_base_rejected(self):
        data = bytearray(self.base.read_bytes())
        data[-5000] ^= 1
        self.base.write_bytes(data)
        self.assertNotEqual(self.add(), 0)
        self.assertFalse(self.dest.exists())

    def test_rejects_application_title(self):
        cia_fixture(self.base, title=0x0004000001111100)
        self.assertNotEqual(self.add(), 0)
        self.assertFalse(self.dest.exists())

    def test_rejects_bad_lz(self):
        (self.theme/'body_LZ.bin').write_bytes(b'\x11\xc4\x00\x00\x80\x20\x00')
        self.assertNotEqual(self.add(), 0)
        self.assertFalse(self.dest.exists())

    def test_music_required_by_theme(self):
        (self.theme/'body_LZ.bin').write_bytes(body(77, music=True))
        self.assertNotEqual(self.add(), 0)
        self.assertIn(b'bgm.bcstm', self.error.value)

    def test_name_not_silently_truncated(self):
        (self.theme/'name.txt').write_text('é'*32, encoding='utf-8')
        self.assertNotEqual(self.add(), 0)

    def test_hundred_theme_limit(self):
        cia_fixture(self.base, count=100)
        self.assertNotEqual(self.add(), 0)
        self.assertIn(b'100', self.error.value)

    def test_truncated_archives(self):
        original = self.base.read_bytes()
        rng = random.Random(7303)
        for length in [0, 0x2020, len(original)-1]+[rng.randrange(len(original)) for _ in range(20)]:
            self.base.write_bytes(original[:length])
            self.assertNotEqual(LIB.tt_verify(path(self.base), self.error), 0)

if __name__ == '__main__':
    unittest.main()
