"""Independent Python format oracle. All test assets are synthetic, not Nintendo data."""
import hashlib
import struct

def align(n, a):
    return (n + a - 1) // a * a

def u32(data, at):
    return struct.unpack_from('<I', data, at)[0]

def u64(data, at):
    return struct.unpack_from('<Q', data, at)[0]

def path_hash(name, parent):
    value = parent ^ 123456789
    for char in name:
        value = ((value >> 5) | (value << 27)) & 0xFFFFFFFF
        value ^= ord(char)
    return value

def romfs(files):
    dirs = ['', 'icons']
    dir_offsets = [0, 24]
    directory_table = bytearray(b'\xff' * 60)
    dh = [0xFFFFFFFF] * 3
    fh = [0xFFFFFFFF] * 257
    file_table = bytearray()
    data = bytearray()
    first = [0xFFFFFFFF, 0xFFFFFFFF]
    last = [None, None]
    for full_name, content in files.items():
        group = int('/' in full_name)
        name = full_name.split('/')[-1]
        parent = dir_offsets[group]
        encoded = name.encode('utf-16le')
        offset = len(file_table)
        data.extend(b'\0' * (align(len(data), 16) - len(data)))
        bucket = path_hash(name, parent) % 257
        file_table.extend(struct.pack('<IIQQII', parent, 0xFFFFFFFF, len(data), len(content), fh[bucket], len(encoded)))
        file_table.extend(encoded + b'\0' * (align(len(encoded), 4) - len(encoded)))
        fh[bucket] = offset
        if last[group] is not None:
            struct.pack_into('<I', file_table, last[group] + 4, offset)
        else:
            first[group] = offset
        last[group] = offset
        data.extend(content)
    for i, name in enumerate(dirs):
        off = dir_offsets[i]
        bucket = path_hash(name, 0) % 3
        struct.pack_into('<IIIIII', directory_table, off, 0, 0xFFFFFFFF, 24 if i == 0 else 0xFFFFFFFF, first[i], dh[bucket], len(name)*2)
        directory_table[off+24:off+24+len(name)*2] = name.encode('utf-16le')
        dh[bucket] = off
    ds = 0x28 + 12
    fhs = ds + len(directory_table)
    fs = fhs + len(fh)*4
    fd = align(fs + len(file_table), 16)
    l3 = bytearray(struct.pack('<10I', 0x28, 0x28, 12, ds, len(directory_table), fhs, len(fh)*4, fs, len(file_table), fd))
    l3.extend(struct.pack('<3I', *dh))
    l3.extend(directory_table)
    l3.extend(struct.pack('<257I', *fh))
    l3.extend(file_table)
    l3.extend(b'\0' * (fd - len(l3)))
    l3.extend(data)
    levels = [None, None, None, bytes(l3)]
    for i in [2, 1, 0]:
        child = levels[i+1]
        padded = child + b'\0' * (align(len(child), 4096) - len(child))
        levels[i] = b''.join(hashlib.sha256(padded[j:j+4096]).digest() for j in range(0, len(padded), 4096))
    result = bytearray(align(0x60+len(levels[0]), 4096))
    result[:4] = b'IVFC'
    struct.pack_into('<II', result, 4, 0x10000, len(levels[0]))
    logical = 0
    for i in [1, 2, 3]:
        struct.pack_into('<QQII', result, 12+24*(i-1), logical, len(levels[i]), 12, 0)
        logical += align(len(levels[i]), 4096)
    struct.pack_into('<I', result, 0x54, 0x5C)
    result[0x60:0x60+len(levels[0])] = levels[0]
    for i in [3, 1, 2]:
        result.extend(levels[i])
        result.extend(b'\0' * (align(len(result), 4096) - len(result)))
    return bytes(result)

def read_romfs(image):
    assert image[:4] == b'IVFC'
    sizes = [u32(image, 8)] + [u64(image, 0x14+24*i) for i in range(3)]
    positions = [0x60, None, None, align(0x60+sizes[0], 4096)]
    positions[1] = positions[3] + align(sizes[3], 4096)
    positions[2] = positions[1] + align(sizes[1], 4096)
    for i in range(3):
        child = image[positions[i+1]:positions[i+1]+align(sizes[i+1], 4096)]
        hashes = b''.join(hashlib.sha256(child[j:j+4096]).digest() for j in range(0, len(child), 4096))
        assert image[positions[i]:positions[i]+sizes[i]] == hashes
    l3 = image[positions[3]:positions[3]+sizes[3]]
    ds, fs, fl, fd = (u32(l3, off) for off in (0xC, 0x1C, 0x20, 0x24))
    files = {}
    off = 0
    while off < fl:
        p, _, do, sz, _, nl = struct.unpack_from('<IIQQII', l3, fs+off)
        name = l3[fs+off+32:fs+off+32+nl].decode('utf-16le')
        if p:
            dnl = u32(l3, ds+p+20)
            name = l3[ds+p+24:ds+p+24+dnl].decode('utf-16le') + '/' + name
        files[name] = l3[fd+do:fd+do+sz]
        # Verify lookup-chain construction independently of sequential traversal.
        fht, fhtn = u32(l3, 0x14), u32(l3, 0x18)//4
        head = u32(l3, fht + path_hash(name.split('/')[-1], p) % fhtn * 4)
        seen = set()
        while head != off:
            assert head != 0xFFFFFFFF and head not in seen
            seen.add(head)
            head = u32(l3, fs+head+24)
        off += 32+align(nl, 4)
    return files

TITLE = 0x0004008C00008F01  # Test-only HTT variation. No real ticket/certificate.

def ncch(files, title=TITLE, index=0):
    image = romfs(files)
    header = bytearray(512)
    header[0x100:0x104] = b'NCCH'
    struct.pack_into('<IQ', header, 0x104, (len(image)+512)//512, title+(index<<48))
    struct.pack_into('<H', header, 0x112, 2)
    struct.pack_into('<Q', header, 0x118, title)
    header[0x150:0x15A] = b'CTR-P-CTAP'
    header[0x18C:0x190] = b'\x01\x01\x00\x04'
    hs = align(0x60+u32(image, 8), 512)
    struct.pack_into('<III', header, 0x1B0, 1, len(image)//512, hs//512)
    header[0x1E0:0x200] = hashlib.sha256(image[:hs]).digest()
    return bytes(header) + image

def literal_lz11(raw):
    return struct.pack('<I', 0x11 | (len(raw)<<8)) + b''.join(b'\0'+raw[i:i+8] for i in range(0, len(raw), 8))

def body(seed=1, music=False):
    raw = bytearray(0xC4)
    struct.pack_into('<I', raw, 0, 1)
    raw[4] = seed
    raw[5] = int(music)
    return literal_lz11(raw)

def cia_fixture(path, title=TITLE, count=1, control_override=None):
    meta = bytearray(0x3C)
    struct.pack_into('<5I', meta, 0, 1, count, count+1, 0x300030, 0xDEADBEEF)
    struct.pack_into('<I', meta, 0x30, 2)
    struct.pack_into('<HHHH', meta, 0x34, 1, 1, 1, 9)
    entries = bytearray(struct.pack('<II', 1, count+1) + b'\0'*200)
    for i in range(1, count+1):
        entry = bytearray(200)
        entry[:len(f'Original {i}')] = f'Original {i}'.encode()
        struct.pack_into('<II', entry, 192, i, 1)
        entries.extend(entry)
    control = {
        'MetaDataContentHeader.bin': bytes(meta),
        'ContentInfoArchive_USA_en.bin': bytes(entries),
        'ContentInfoArchive_USA_pt.bin': bytes(entries),
        **{f'icons/{i}.icn': bytes([i % 255])*4608 for i in range(1, count+1)},
    }
    if control_override is not None:
        control = control_override
    contents = [(0, ncch(control, title))] + [(i, ncch({'body_LZ.bin': body(i)}, title, i)) for i in range(1,count+1)]
    tmd = bytearray(0xB04+len(contents)*48)
    struct.pack_into('>I', tmd, 0, 0x10004)
    struct.pack_into('>Q', tmd, 0x18C, title)
    struct.pack_into('>HH', tmd, 0x1DC, 1, len(contents))
    for i, (index, data) in enumerate(contents):
        struct.pack_into('>IHHQ', tmd, 0xB04+i*48, 0xAB0000+i, index, 0 if not index else 0x4000, len(data))
        tmd[0xB14+i*48:0xB34+i*48] = hashlib.sha256(data).digest()
    struct.pack_into('>HH', tmd, 0x204, 0, len(contents))
    tmd[0x208:0x228] = hashlib.sha256(tmd[0xB04:]).digest()
    tmd[0x1E4:0x204] = hashlib.sha256(tmd[0x204:0xB04]).digest()
    ticket = bytearray(0x350)
    struct.pack_into('>I', ticket, 0, 0x10004)
    struct.pack_into('>Q', ticket, 0x1DC, title)
    struct.pack_into('>10I', ticket, 0x2A4, 0x10014, 0xAC, 0x14, 0x10014, 0, 0x28, 1, 0x84, 0x84, 0x30000)
    for i in range(count+1):
        ticket[0x2D0+i//8] |= 1 << (i % 8)
    cert = bytes(0xA00)
    header = bytearray(0x2020)
    struct.pack_into('<IHHIIIIQ', header, 0, len(header), 0, 0, len(cert), len(ticket), len(tmd), 0, sum(len(x[1]) for x in contents))
    for index, _ in contents:
        header[0x20+index//8] |= 0x80 >> (index%8)
    image = bytearray(header)
    for section in (cert, ticket, tmd):
        image.extend(b'\0'*(align(len(image),64)-len(image)))
        image.extend(section)
    image.extend(b'\0'*(align(len(image),64)-len(image)))
    for _, content in contents:
        image.extend(content)
    path.write_bytes(image)
    return control, contents

def read_cia(path):
    image = path.read_bytes()
    certn,tikn,tmdn,_ = struct.unpack_from('<4I', image, 8)
    tk = align(align(0x2020,64)+certn,64)
    tm = align(tk+tikn,64)
    start = align(tm+tmdn,64)
    tmd = image[tm:tm+tmdn]
    assert hashlib.sha256(tmd[0x204:0xB04]).digest() == tmd[0x1E4:0x204]
    count = struct.unpack_from('>H', tmd, 0x1DE)[0]
    assert hashlib.sha256(tmd[0xB04:0xB04+count*48]).digest() == tmd[0x208:0x228]
    contents = {}
    for i in range(count):
        cid,index,kind,size = struct.unpack_from('>IHHQ',tmd,0xB04+i*48)
        content = image[start:start+size]
        assert hashlib.sha256(content).digest() == tmd[0xB14+i*48:0xB34+i*48]
        romoff,romsz,hashsz = struct.unpack_from('<3I',content,0x1B0)
        rom = content[romoff*512:(romoff+romsz)*512]
        assert hashlib.sha256(rom[:hashsz*512]).digest() == content[0x1E0:0x200]
        contents[index] = (content, read_romfs(rom))
        assert image[tk+0x2D0+index//8] & (1 << (index%8))
        start += size
    return image, contents
