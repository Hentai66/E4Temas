/* Nonfatal boot diagnostics. No title database, tickets or theme data are modified. */
#include "startup.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
static char log_path[128];
void startup_record(const char *stage, Result result) {
    FILE *file;
    if(!log_path[0])return;
    file=fopen(log_path,"ab");
    if(!file)return;
    fprintf(file,"%s result=%08lX\n",stage,(unsigned long)(u32)result);
    fflush(file);fclose(file);
}
void startup_begin(const char *name, ThemeBootInfo *info) {
    memset(info,0,sizeof(*info));
    info->detected_result=FSUSER_IsSdmcDetected(&info->detected);
    info->writable_result=FSUSER_IsSdmcWritable(&info->writable);
    if(R_SUCCEEDED(info->detected_result)&&info->detected&&
       R_SUCCEEDED(info->writable_result)&&info->writable) {
        mkdir("sdmc:/3ds",0777);mkdir("sdmc:/3ds/scl-temas",0777);
        snprintf(log_path,sizeof(log_path),"sdmc:/3ds/scl-temas/boot-%s.log",name);
    }
    startup_record("version=1.1.1 main.enter",0);
    startup_record(envIsHomebrew()?"format=3dsx":"format=cia",0);
    startup_record(info->detected?"sd.detected=true":"sd.detected=false",info->detected_result);
    startup_record(info->writable?"sd.writable=true":"sd.writable=false",info->writable_result);
}
