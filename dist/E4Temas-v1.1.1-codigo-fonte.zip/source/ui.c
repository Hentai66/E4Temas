/* Small software renderer: same code can render native framebuffers and host previews. */
#include "ui.h"
#include "ui_assets.h"
static unsigned char *screen;
static int width,light_logo;
UIPalette ui_colors;
void ui_theme(int light){
    UIPalette dark={0x181b1d,0x27242e,0xeee1ff,0xb9a8c9,0xa05ce7};
    UIPalette pale={0xf2eafb,0xe4d4f2,0x352142,0x725787,0x8543bd};
    ui_colors=light?pale:dark;light_logo=light;
}
void ui_surface(unsigned char*p,int w){screen=p;width=w;}
static void pixel(int x,int y,uint32_t c,unsigned a){unsigned char*p;
    if(x<0||y<0||x>=width||y>=240)return;p=screen+(x*240+239-y)*3;
    p[0]=(unsigned char)((p[0]*(255-a)+(c&255)*a)/255);
    p[1]=(unsigned char)((p[1]*(255-a)+((c>>8)&255)*a)/255);
    p[2]=(unsigned char)((p[2]*(255-a)+((c>>16)&255)*a)/255);
}
void ui_rect(int x,int y,int w,int h,uint32_t c){int a,b;
    for(a=x;a<x+w;a++)for(b=y;b<y+h;b++)pixel(a,b,c,255);
}
void ui_clear(void){ui_rect(0,0,width,240,ui_colors.bg);}
void ui_text(int x,int y,const char*s,uint32_t c,int limit){int n=0,origin=x;
    while(*s&&n<limit){unsigned ch=(unsigned char)*s++,a,b;
        if(ch=='\n'){y+=17;x=origin;n=0;continue;}
        if(ch>=0xc2&&ch<=0xc3&&((unsigned char)*s&0xc0)==0x80){ch=((ch&31)<<6)|((unsigned char)*s++&63);}
        else if(ch>=128){while(((unsigned char)*s&0xc0)==0x80)s++;ch='?';}
        for(b=0;b<16;b++)for(a=0;a<8;a++)if(e4_font[ch*128+b*8+a])pixel(x+a,y+b,c,e4_font[ch*128+b*8+a]);
        x+=8;n++;
    }
}
void ui_logo(int x,int y){unsigned a,b;for(b=0;b<32;b++)for(a=0;a<32;a++){
    const unsigned char*p=(light_logo?e4_logo_light:e4_logo_dark)+(b*32+a)*4;pixel(x+a,y+b,((uint32_t)p[0]<<16)|((uint32_t)p[1]<<8)|p[2],p[3]);
}}
