#include "tt.h"
#include "sha256.h"
#include "import.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <limits.h>
#include <errno.h>
#include <fcntl.h>
#ifdef _WIN32
#include <io.h>
#define open _open
#define close _close
#define fdopen _fdopen
#define fsync _commit
#define fileno _fileno
#else
#include <unistd.h>
#endif
#ifndef O_BINARY
#define O_BINARY 0
#endif

static TTProgress progress_callback;
static unsigned verify_start,verify_span;
void tt_set_progress(TTProgress callback){progress_callback=callback;}
void tt_progress(const char*stage,unsigned percent){if(progress_callback)progress_callback(stage,percent);}
typedef unsigned char U8;
typedef struct {char name[128];U8 *data;size_t size;} RFile;
typedef struct {RFile files[256];unsigned count;} RFiles;
static int fail(char *e,const char *fmt,...) {va_list a;va_start(a,fmt);vsnprintf(e,TT_ERROR_SIZE,fmt,a);va_end(a);return -1;}
static uint16_t le16(const U8*p){return p[0]|((uint16_t)p[1]<<8);}
static uint32_t le32(const U8*p){return le16(p)|((uint32_t)le16(p+2)<<16);}
static uint64_t le64(const U8*p){return le32(p)|((uint64_t)le32(p+4)<<32);}
static uint16_t be16(const U8*p){return ((uint16_t)p[0]<<8)|p[1];}
static uint32_t be32(const U8*p){return ((uint32_t)be16(p)<<16)|be16(p+2);}
static uint64_t be64(const U8*p){return ((uint64_t)be32(p)<<32)|be32(p+4);}
static void wl16(U8*p,uint16_t v){p[0]=(U8)v;p[1]=(U8)(v>>8);}
static void wl32(U8*p,uint32_t v){wl16(p,(uint16_t)v);wl16(p+2,(uint16_t)(v>>16));}
static void wl64(U8*p,uint64_t v){wl32(p,(uint32_t)v);wl32(p+4,(uint32_t)(v>>32));}
static void wb16(U8*p,uint16_t v){p[0]=(U8)(v>>8);p[1]=(U8)v;}
static void wb32(U8*p,uint32_t v){wb16(p,(uint16_t)(v>>16));wb16(p+2,(uint16_t)v);}
static void wb64(U8*p,uint64_t v){wb32(p,(uint32_t)(v>>32));wb32(p+4,(uint32_t)v);}
static size_t al(size_t n,size_t a){return (n+a-1)&~(a-1);}
static int range(uint64_t off,uint64_t n,uint64_t end){return off<=end&&n<=end-off;}
static int readat(FILE*f,uint64_t off,void*p,size_t n){return off<=LONG_MAX&&!fseek(f,(long)off,SEEK_SET)&&fread(p,1,n,f)==n;}
static U8 *loadpart(FILE*f,uint64_t off,size_t n){U8*p=malloc(n?n:1);if(p&&!readat(f,off,p,n)){free(p);p=NULL;}return p;}
void tt_free(void*p){free(p);}

/* Bounded LZ11 decoder. Malformed streams never reach the console installer. */
int tt_lz11(const U8 *p,size_t n,U8 **out,size_t *outn,char *e) {
    size_t i=4,j=0,size;U8*b;*out=NULL;*outn=0;
    if(n<4||p[0]!=0x11)return fail(e,"body_LZ.bin nao e LZ11");
    size=le32(p)>>8;if(!size){if(n<8)return fail(e,"LZ11 truncado");size=le32(p+4);i=8;}
    if(size<0xC4||size>0x150000)return fail(e,"Tamanho descomprimido fora do limite de tema");
    b=malloc(size);if(!b)return fail(e,"Memoria insuficiente");
    while(j<size){unsigned bit,flags;if(i>=n)goto bad;flags=p[i++];
        for(bit=0;bit<8&&j<size;bit++) {
            size_t len,dist;unsigned a,c,d,v;
            if(!(flags&(0x80>>bit))){if(i>=n)goto bad;b[j++]=p[i++];continue;}
            if(i+2>n)goto bad;a=p[i++];v=a>>4;
            if(v==0){if(i+2>n)goto bad;c=p[i++];d=p[i++];len=((a&15)<<4)+(c>>4)+0x11;dist=((c&15)<<8)+d+1;}
            else if(v==1){if(i+3>n)goto bad;c=p[i++];d=p[i++];len=((a&15)<<12)+(c<<4)+(d>>4)+0x111;dist=((d&15)<<8)+p[i++]+1;}
            else{len=v+1;dist=((a&15)<<8)+p[i++]+1;}
            if(dist>j||len>size-j)goto bad;
            while(len--){b[j]=b[j-dist];j++;}
        }
    }
    if(le32(b)!=1||le32(b+0xC)>=4||le32(b+0x20)>=4||le32(b+0x20)==2){free(b);return fail(e,"Cabecalho de tema invalido");}
    *out=b;*outn=size;return 0;
bad:free(b);return fail(e,"LZ11 truncado ou referencia invalida");
}

static int theme_title(uint64_t id) {
    uint32_t low=(uint32_t)id&0xFFFFFF00;
    return (id>>32)==0x0004008C&&(low==0x8200||low==0x8F00||low==0x9800);
}
int tt_inspect(const char*path,TTPackage*p,char*e) {
    FILE*f=fopen(path,"rb");U8 h[0x2020],th[0xB04],r[0x30],tk[0x1E4];uint64_t off,total=0;unsigned i,j;long sz;
    memset(p,0,sizeof(*p));e[0]=0;if(!f)return fail(e,"Nao foi possivel abrir CIA: %s",path);
    if(fseek(f,0,SEEK_END)||(sz=ftell(f))<0){fclose(f);return fail(e,"Erro lendo tamanho");}p->file_size=(uint64_t)sz;
    if(!readat(f,0,h,sizeof(h))||le32(h)!=0x2020||le16(h+4)||le16(h+6))goto invalid;
    p->cert_size=le32(h+8);p->ticket_size=le32(h+12);p->tmd_size=le32(h+16);
    if(!p->cert_size||p->cert_size>0x10000||p->ticket_size<0x350||p->ticket_size>0x10000||p->tmd_size>0x10000)goto invalid;
    p->cert_offset=al(sizeof(h),64);p->ticket_offset=al((size_t)p->cert_offset+p->cert_size,64);
    p->tmd_offset=al((size_t)p->ticket_offset+p->ticket_size,64);p->content_offset=al((size_t)p->tmd_offset+p->tmd_size,64);
    if(!range(p->tmd_offset,p->tmd_size,p->file_size)||!readat(f,p->tmd_offset,th,sizeof(th))||be32(th)!=0x10004)goto invalid;
    p->title_id=be64(th+0x18C);p->version=be16(th+0x1DC);p->count=be16(th+0x1DE);
    if(!theme_title(p->title_id)||!p->count||p->count>TT_MAX_CONTENTS||p->tmd_size<0xB04U+0x30U*p->count)goto invalid;
    if(!readat(f,p->ticket_offset,tk,sizeof(tk))||be32(tk)!=0x10004||be64(tk+0x1DC)!=p->title_id)goto invalid;
    off=p->content_offset;
    for(i=0;i<p->count;i++) {
        TTContent*c=&p->contents[i];
        if(!readat(f,p->tmd_offset+0xB04+0x30*i,r,sizeof(r)))goto invalid;
        c->id=be32(r);c->index=be16(r+4);c->type=be16(r+6);c->size=be64(r+8);c->offset=off;memcpy(c->hash,r+16,32);
        if(c->index>1023||(c->type&1)||c->size<512||c->size>0x800000||!range(off,c->size,p->file_size))goto invalid;
        if(!(h[0x20+c->index/8]&(0x80>>(c->index%8))))goto invalid;
        if(i==0&&c->index)goto invalid;
        for(j=0;j<i;j++)if(p->contents[j].index==c->index||p->contents[j].id==c->id)goto invalid;
        off+=c->size;total+=c->size;
    }
    /* Restrict to full archives with no extra bitmap contents; offsets are contiguous. */
    for(i=0;i<65536;i++)if(h[0x20+i/8]&(0x80>>(i%8))){int found=0;for(j=0;j<p->count;j++)if(p->contents[j].index==i)found=1;if(!found)goto invalid;}
    if(le64(h+0x18)!=total||!range(p->content_offset,total,p->file_size))goto invalid;
    fclose(f);return 0;
invalid:fclose(f);return fail(e,"CIA incompativel: requer pacote HTT completo, descriptografado, JPN/USA/EUR");
}

static int verify_ivfc(const U8*p,size_t n,char*e) {
    size_t size[4],pos[4],i,j;U8 hash[32];
    if(n<0x1000||memcmp(p,"IVFC",4)||le32(p+4)!=0x10000)return fail(e,"RomFS sem IVFC valido");
    size[0]=le32(p+8);pos[0]=0x60;
    for(i=1;i<=3;i++){if(le32(p+0x1C+24*(i-1))!=12)return fail(e,"Blocos IVFC nao suportados");size[i]=(size_t)le64(p+0x14+24*(i-1));if(size[i]>0x800000)return fail(e,"RomFS muito grande");}
    pos[3]=al(0x60+size[0],4096);pos[1]=pos[3]+al(size[3],4096);pos[2]=pos[1]+al(size[1],4096);
    if(le64(p+0xC)!=0||le64(p+0x24)!=al(size[1],4096)||le64(p+0x3C)!=al(size[1],4096)+al(size[2],4096))return fail(e,"Offsets IVFC invalidos");
    for(i=0;i<4;i++)if(!range(pos[i],i?al(size[i],4096):size[i],n))return fail(e,"IVFC truncado");
    for(i=0;i<3;i++) {
        if(size[i]!=(al(size[i+1],4096)/4096)*32)return fail(e,"Tamanho da arvore IVFC invalido");
        for(j=0;j<size[i]/32;j++){tt_sha256(p+pos[i+1]+4096*j,4096,hash);if(memcmp(hash,p+pos[i]+j*32,32))return fail(e,"Hash IVFC incorreto");}
    }
    return 0;
}
static int verify_ncch(const U8*p,size_t n,uint64_t title,char*e) {
    uint64_t off,sz,hs;U8 hash[32];
    if(n<512||memcmp(p+0x100,"NCCH",4)||le32(p+0x104)*512ULL!=n||!(p[0x18F]&4)||p[0x18E]||le32(p+0x180)||le64(p+0x118)!=title)return fail(e,"NCCH incompativel ou criptografado");
    if(le32(p+0x1A0)){
        uint64_t xo=le32(p+0x1A0)*512ULL,xs=le32(p+0x1A4)*512ULL,xh=le32(p+0x1A8)*512ULL;unsigned k;
        if(xo<512||xs<512||!xh||xh>xs||!range(xo,xs,n)||xo+xs>le32(p+0x1B0)*512ULL)return fail(e,"ExeFS invalida");
        tt_sha256(p+xo,(size_t)xh,hash);if(memcmp(hash,p+0x1C0,32))return fail(e,"Hash ExeFS incorreto");
        for(k=0;k<10;k++){const U8*v=p+xo+k*16;uint64_t pos=le32(v+8),size=le32(v+12);if(!v[0])continue;
            if(memcmp(v,"icon\0\0\0\0",8)||size!=0x36C0||!range(512+pos,size,xs)||memcmp(p+xo+512+pos,"SMDH",4))return fail(e,"ExeFS de controle invalida");
            tt_sha256(p+xo+512+pos,(size_t)size,hash);if(memcmp(hash,p+xo+0x1E0-k*32,32))return fail(e,"Hash SMDH incorreto");
        }
    }
    off=le32(p+0x1B0)*512ULL;sz=le32(p+0x1B4)*512ULL;hs=le32(p+0x1B8)*512ULL;
    if(off<512||!sz||!hs||hs>sz||!range(off,sz,n))return fail(e,"Regiao RomFS invalida");
    tt_sha256(p+(size_t)off,(size_t)hs,hash);if(memcmp(hash,p+0x1E0,32))return fail(e,"Hash NCCH incorreto");
    return verify_ivfc(p+(size_t)off,(size_t)sz,e);
}
int tt_verify(const char*path,char*e) {
    TTPackage p;FILE*f;U8*h=NULL,*buf=NULL,hash[32];unsigned i,j;uint32_t cursor=0;
    if(tt_inspect(path,&p,e))return -1;f=fopen(path,"rb");if(!f)return fail(e,"Erro abrindo CIA");
    h=loadpart(f,p.tmd_offset,p.tmd_size);if(!h)goto io;
    tt_sha256(h+0x204,0x900,hash);if(memcmp(hash,h+0x1E4,32)){fail(e,"Hash dos registros TMD incorreto");goto bad;}
    for(i=0;i<64;i++){U8*r=h+0x204+i*36;unsigned start=be16(r),count=be16(r+2);
        if(!count)continue;if(start!=cursor||count>p.count-cursor){fail(e,"Grupos TMD invalidos");goto bad;}
        tt_sha256(h+0xB04+start*48,count*48,hash);if(memcmp(hash,r+4,32)){fail(e,"Hash do grupo TMD incorreto");goto bad;}cursor+=count;}
    if(cursor!=p.count){fail(e,"TMD nao cobre todos os conteudos");goto bad;}
    for(i=0;i<p.count;i++) {
        TTContent*c=&p.contents[i];
        buf=loadpart(f,c->offset,(size_t)c->size);if(!buf)goto io;
        tt_sha256(buf,(size_t)c->size,hash);
        if(memcmp(hash,c->hash,32)){fail(e,"Hash SHA-256 incorreto no conteudo %u",c->index);goto bad;}
        j=verify_ncch(buf,(size_t)c->size,p.title_id,e);free(buf);buf=NULL;if(j)goto bad;
        tt_progress("Verificando conteudos",verify_start+verify_span*(i+1)/p.count);
    }
    free(h);fclose(f);return 0;
io:fail(e,"Erro de leitura ou memoria insuficiente");
bad:free(h);free(buf);fclose(f);return -1;
}

static void rfree(RFiles*r){unsigned i;for(i=0;i<r->count;i++)free(r->files[i].data);free(r);}
static RFile*rfind(RFiles*r,const char*name){unsigned i;for(i=0;i<r->count;i++)if(!strcmp(r->files[i].name,name))return&r->files[i];return NULL;}
static int rput(RFiles*r,const char*name,const void*p,size_t n,char*e){RFile*f=rfind(r,name);U8*b;
    if(strlen(name)>=128||n>0x600000||(!f&&r->count==256))return fail(e,"Limite de arquivos RomFS");
    b=malloc(n?n:1);if(!b)return fail(e,"Memoria insuficiente");memcpy(b,p,n);
    if(!f){f=&r->files[r->count++];memset(f,0,sizeof(*f));strcpy(f->name,name);}else free(f->data);
    f->data=b;f->size=n;return 0;}
/* Control contents use ASCII paths, with only the optional icons/ directory. */
static RFiles *rparse(const U8*p,size_t n,char*e) {
    RFiles*r=calloc(1,sizeof(*r));size_t l3,ds,dl,fs,fl,fd,pos;const U8*q;
    if(!r){fail(e,"Memoria insuficiente");return NULL;}l3=al(0x60+le32(p+8),4096);
    if(!range(l3,0x28,n)){fail(e,"RomFS truncado");goto bad;}q=p+l3;n-=l3;
    ds=le32(q+0xC);dl=le32(q+0x10);fs=le32(q+0x1C);fl=le32(q+0x20);fd=le32(q+0x24);
    if(le32(q)!=0x28||!range(ds,dl,n)||!range(fs,fl,n)||fd>n)goto invalid;
    for(pos=0;pos<fl;){const U8*f=q+fs+pos;uint32_t parent,nl;size_t i,z=0;char name[128];uint64_t off,sz;
        if(!range(pos,32,fl))goto invalid;parent=le32(f);nl=le32(f+28);off=le64(f+8);sz=le64(f+16);
        if(nl>180||(nl&1)||!range(pos,32+al(nl,4),fl)||!range(off,sz,n-fd))goto invalid;
        if(parent){const U8*d;if(!range(parent,24,dl))goto invalid;d=q+ds+parent;
            if(le32(d)!=0||le32(d+20)!=10||!range(parent,36,dl)||memcmp(d+24,"i\0c\0o\0n\0s\0",10))goto invalid;
            memcpy(name,"icons/",6);z=6;}
        for(i=0;i<nl;i+=2){if(f[32+i]<32||f[33+i]||f[32+i]=='/'||f[32+i]=='\\')goto invalid;name[z++]=(char)f[32+i];}name[z]=0;
        if(!z||rfind(r,name)||rput(r,name,q+fd+(size_t)off,(size_t)sz,e))goto bad;
        pos+=32+al(nl,4);
    }
    return r;
invalid:fail(e,"Estrutura do controle RomFS nao suportada");
bad:rfree(r);return NULL;
}
static uint32_t pathhash(const char*s,uint32_t parent){uint32_t h=parent^123456789;while(*s){h=(h>>5)|(h<<27);h^=(unsigned char)*s++;}return h;}
static void uname(U8*p,const char*s){while(*s){wl16(p,(unsigned char)*s++);p+=2;}}
static int rbuild(RFiles*r,U8**out,size_t*outn,char*e) {
    size_t dm=0x3C,ds=0x28+12,fh,fs,fm=0,fd,data=0,l3sz,sizes[4],pos[4],logical=0,total;
    unsigned i,j;size_t fo[256],doff[256];U8*p,*q;uint32_t bucket,head[2]={0xFFFFFFFF,0xFFFFFFFF},tail[2]={0xFFFFFFFF,0xFFFFFFFF};
    for(i=0;i<r->count;i++){const char*s=strrchr(r->files[i].name,'/');s=s?s+1:r->files[i].name;fo[i]=fm;fm+=32+al(strlen(s)*2,4);doff[i]=al(data,16);data=doff[i]+r->files[i].size;}
    fh=ds+dm;fs=fh+257*4;fd=al(fs+fm,16);l3sz=fd+data;if(l3sz>0x700000)return fail(e,"RomFS excede memoria disponivel");
    sizes[3]=l3sz;for(i=3;i>0;i--)sizes[i-1]=(al(sizes[i],4096)/4096)*32;
    pos[0]=0x60;pos[3]=al(pos[0]+sizes[0],4096);pos[1]=pos[3]+al(sizes[3],4096);pos[2]=pos[1]+al(sizes[1],4096);total=pos[2]+al(sizes[2],4096);
    p=calloc(1,total);if(!p)return fail(e,"Memoria insuficiente para RomFS");memcpy(p,"IVFC",4);wl32(p+4,0x10000);wl32(p+8,(uint32_t)sizes[0]);wl32(p+0x54,0x5C);
    for(i=1;i<4;i++){wl64(p+0xC+24*(i-1),logical);wl64(p+0x14+24*(i-1),sizes[i]);wl32(p+0x1C+24*(i-1),12);logical+=al(sizes[i],4096);}
    q=p+pos[3];wl32(q,0x28);wl32(q+4,0x28);wl32(q+8,12);wl32(q+0xC,(uint32_t)ds);wl32(q+0x10,(uint32_t)dm);wl32(q+0x14,(uint32_t)fh);wl32(q+0x18,257*4);wl32(q+0x1C,(uint32_t)fs);wl32(q+0x20,(uint32_t)fm);wl32(q+0x24,(uint32_t)fd);
    memset(q+0x28,0xFF,12);memset(q+fh,0xFF,257*4);memset(q+ds,0xFF,dm);
    for(i=0;i<2;i++){size_t d=i?24:0;const char*name=i?"icons":"";U8*v=q+ds+d;wl32(v,0);wl32(v+8,i?0xFFFFFFFF:24);wl32(v+20,(uint32_t)strlen(name)*2);uname(v+24,name);bucket=pathhash(name,0)%3;wl32(v+16,le32(q+0x28+bucket*4));wl32(q+0x28+bucket*4,(uint32_t)d);}
    for(i=0;i<r->count;i++){RFile*f=&r->files[i];const char*slash=strchr(f->name,'/');const char*name=slash?slash+1:f->name;unsigned group=slash?1:0;uint32_t parent=group?24:0;U8*v=q+fs+fo[i];
        if(slash&&(strncmp(f->name,"icons/",6)||strchr(name,'/'))){free(p);return fail(e,"Caminho RomFS nao suportado");}
        memset(v,0xFF,32);wl32(v,parent);wl64(v+8,doff[i]);wl64(v+16,f->size);wl32(v+28,(uint32_t)strlen(name)*2);uname(v+32,name);
        if(head[group]==0xFFFFFFFF)head[group]=(uint32_t)fo[i];else wl32(q+fs+tail[group]+4,(uint32_t)fo[i]);tail[group]=(uint32_t)fo[i];
        bucket=pathhash(name,parent)%257;wl32(v+24,le32(q+fh+bucket*4));wl32(q+fh+bucket*4,(uint32_t)fo[i]);memcpy(q+fd+doff[i],f->data,f->size);
    }
    wl32(q+ds+12,head[0]);wl32(q+ds+24+12,head[1]);
    for(i=3;i>0;i--)for(j=0;j<sizes[i-1]/32;j++)tt_sha256(p+pos[i]+4096*j,4096,p+pos[i-1]+32*j);
    *out=p;*outn=total;return 0;
}
/* Control content needs an ExeFS SMDH as in native theme DLC/HTT.
   This is original metadata, not Nintendo's icon or strings. */
static int ncchbuild(RFiles*r,const U8*template_header,uint16_t index,U8**out,size_t*outn,char*e) {
    U8*rom=NULL,*p;size_t n,hs,exesize=index?0:0x3A00,romoff=al(512+exesize,4096);unsigned i;
    if(rbuild(r,&rom,&n,e))return -1;
    p=calloc(1,n+romoff);if(!p){free(rom);return fail(e,"Memoria insuficiente");}
    memcpy(p,template_header,0x200);memset(p,0,0x100);memcpy(p+0x110,"00",2);wl16(p+0x112,0);
    wl32(p+0x104,(uint32_t)(n+romoff)/512);wl64(p+0x108,le64(template_header+0x118)+((uint64_t)index<<48));
    memset(p+0x180,0,0x60);p[0x18C]=1;p[0x18D]=1;p[0x18F]=5;
    if(!index){
        U8*ex=p+512,*smdh=ex+512;memcpy(ex,"icon",4);wl32(ex+12,0x36C0);
        memcpy(smdh,"SMDH",4);
        for(i=0;i<16;i++){uname(smdh+8+i*0x200,"Temas");uname(smdh+0x88+i*0x200,"Catalogo de temas");uname(smdh+0x188+i*0x200,"Homebrew");}
        wl32(smdh+0x2018,((uint32_t)le64(template_header+0x118)&0xFFFFFF00)==0x8200?1:((uint32_t)le64(template_header+0x118)&0xFFFFFF00)==0x8F00?2:4);wl32(smdh+0x2028,1);
        for(i=0x2040;i<0x36C0;i+=2)wl16(smdh+i,0x249F);
        tt_sha256(smdh,0x36C0,ex+0x1E0);
        wl32(p+0x1A0,1);wl32(p+0x1A4,(uint32_t)exesize/512);wl32(p+0x1A8,1);
        tt_sha256(ex,512,p+0x1C0);
    }
    wl32(p+0x1B0,(uint32_t)romoff/512);wl32(p+0x1B4,(uint32_t)n/512);hs=al(0x60+le32(rom+8),512);wl32(p+0x1B8,(uint32_t)hs/512);
    memcpy(p+romoff,rom,n);tt_sha256(rom,hs,p+0x1E0);free(rom);*out=p;*outn=n+romoff;return 0;
}

/* A valid name is UTF-8 and fits the native 63-byte field without truncation. */
static int utf8name(const U8*p,size_t n) {
    size_t i=0;if(!n||n>63)return 0;
    while(i<n){uint32_t cp;unsigned more;U8 c=p[i++];if(c<0x80){if(c<32||c==127)return 0;continue;}
        if(c>=0xC2&&c<=0xDF){cp=c&31;more=1;}else if(c>=0xE0&&c<=0xEF){cp=c&15;more=2;}else if(c>=0xF0&&c<=0xF4){cp=c&7;more=3;}else return 0;
        if(i+more>n)return 0;{unsigned k;for(k=0;k<more;k++){c=p[i++];if((c&0xC0)!=0x80)return 0;cp=(cp<<6)|(c&63);}}
        if((more==1&&cp<0x80)||(more==2&&cp<0x800)||(more==3&&cp<0x10000)||cp>0x10FFFF||(cp>=0xD800&&cp<=0xDFFF))return 0;
    }return 1;
}
static size_t smdh_name(const U8*p,char*out){size_t i=0,j=0;while(i<64){uint32_t cp=le16(p+i*2);U8 encoded[4];unsigned len;
    i++;if(!cp)break;if(cp>=0xD800&&cp<=0xDBFF){uint32_t low;if(i>=64)return 0;low=le16(p+i*2);i++;if(low<0xDC00||low>0xDFFF)return 0;cp=0x10000+((cp-0xD800)<<10)+(low-0xDC00);}else if(cp>=0xDC00&&cp<=0xDFFF)return 0;
    if(cp<32||cp==127)cp=' ';
    if(cp<0x80){len=1;encoded[0]=(U8)cp;}else if(cp<0x800){len=2;encoded[0]=(U8)(0xC0|(cp>>6));encoded[1]=(U8)(0x80|(cp&63));}
    else if(cp<0x10000){len=3;encoded[0]=(U8)(0xE0|(cp>>12));encoded[1]=(U8)(0x80|((cp>>6)&63));encoded[2]=(U8)(0x80|(cp&63));}
    else{len=4;encoded[0]=(U8)(0xF0|(cp>>18));encoded[1]=(U8)(0x80|((cp>>12)&63));encoded[2]=(U8)(0x80|((cp>>6)&63));encoded[3]=(U8)(0x80|(cp&63));}
    if(j+len>63)break;memcpy(out+j,encoded,len);j+=len;}out[j]=0;return j;}
static void fallback_name(const char*input,char out[64]){const char*s=strrchr(input,'/');size_t n,k;s=s?s+1:input;n=strlen(s);
    if(n>=4&&(!strcmp(s+n-4,".cia")||!strcmp(s+n-4,".CIA")||!strcmp(s+n-4,".zip")||!strcmp(s+n-4,".ZIP")))n-=4;
    k=n>63?63:n;while(k&&k<n&&(((unsigned char)s[k]&0xC0)==0x80))k--;
    if(!utf8name((const U8*)s,k)){strcpy(out,"Tema importado");return;}memcpy(out,s,k);out[k]=0;}
static U8 *fromfolder(const char*folder,const char*name,size_t*n,size_t max) {return tt_asset(folder,name,n,max);}
static int themefiles(const char*folder,RFiles*r,char name[64],U8 icon[4608],char*e) {
    U8 *p=NULL,*dec=NULL,*smdh=NULL;size_t n=0,dn=0,sn=0;int bgm;unsigned i;
    p=fromfolder(folder,"name.txt",&n,256);if(p){while(n&&(p[n-1]=='\r'||p[n-1]=='\n'))n--;if(n>=3&&!memcmp(p,"\xEF\xBB\xBF",3)){memmove(p,p+3,n-3);n-=3;}
        if(!utf8name(p,n)){free(p);return fail(e,"name.txt: use UTF-8, de 1 a 63 bytes");}memcpy(name,p,n);name[n]=0;free(p);}
    else {smdh=fromfolder(folder,"info.smdh",&sn,0x36C0);name[0]=0;if(smdh&&sn==0x36C0&&!memcmp(smdh,"SMDH",4)){
        if(!smdh_name(smdh+0x208,name))smdh_name(smdh+8,name);}free(smdh);smdh=NULL;if(!name[0])fallback_name(folder,name);}
    tt_progress("Extraindo imagem",24);
    p=fromfolder(folder,"body_LZ.bin",&n,0x150000);if(!p)return fail(e,"Tema incompativel ou corrompido. CIA deve ser um instalador sem criptografia com um ZIP de tema embutido; ZIP/pasta deve conter body_LZ.bin valido.");
    if(tt_lz11(p,n,&dec,&dn,e)){free(p);return -1;}bgm=dec[5]!=0;free(dec);
    if(rput(r,"body_LZ.bin",p,n,e)){free(p);return -1;}free(p);
    tt_progress("Extraindo audio",29);
    p=fromfolder(folder,"bgm.bcstm",&n,0x337000);
    if(bgm&&!p)return fail(e,"Tema requer bgm.bcstm valido");
    if(p){if(n<0x40||memcmp(p,"CSTM",4)||le16(p+4)!=0xFEFF||le32(p+12)!=n){free(p);return fail(e,"bgm.bcstm invalido");}
        if(rput(r,"bgm.bcstm",p,n,e)){free(p);return -1;}free(p);}
    p=fromfolder(folder,"icon.icn",&n,4608);if(p&&n==4608){memcpy(icon,p,4608);free(p);return 0;}free(p);
    p=fromfolder(folder,"icon.png",&n,1024*1024);if(p){int ok=tt_png_icon(p,n,icon);free(p);if(!ok)return fail(e,"icon.png: use PNG de 48x48 pixels");return 0;}
    smdh=fromfolder(folder,"info.smdh",&sn,0x36C0);if(smdh&&sn==0x36C0&&!memcmp(smdh,"SMDH",4)){memcpy(icon,smdh+0x24C0,4608);free(smdh);return 0;}free(smdh);
    /* Deterministic fallback. PNG conversion is offered by the preparation tool. */
    for(i=0;i<2304;i++)wl16(icon+i*2,0x249F);return 0;
}
static int catalog_normalize(RFiles*r,char*e) {
    unsigned i;RFile*jp=rfind(r,"ContentInfoArchive_JPN_jp.bin");
    if(jp)snprintf(jp->name,sizeof(jp->name),"ContentInfoArchive_JPN_ja.bin");
    for(i=0;i<r->count;i++){RFile*f=&r->files[i];uint32_t entries,count;
        if(strncmp(f->name,"ContentInfoArchive_",19))continue;
        if(f->size<208||(f->size-8)%200||le32(f->data)!=1)return fail(e,"Catalogo de idioma invalido");
        entries=(uint32_t)(f->size-8)/200;count=le32(f->data+4);
        if((count!=entries&&count!=entries-1)||le32(f->data+8+192)||le32(f->data+8+196))return fail(e,"Contagem ou entrada dummy invalida");
        wl32(f->data+4,entries-1);
    }return 0;
}
static int catalog_add(RFiles*r,uint16_t index,const char*name,const U8 icon[4608],char*e) {
    RFile*meta=rfind(r,"MetaDataContentHeader.bin");unsigned i,langs=0;char path[64];U8 entry[200]={0};
    if(!meta||meta->size<0x34||le32(meta->data)!=1||le32(meta->data+0x10)!=0xDEADBEEF)return fail(e,"Metadados HTT invalidos");
    if(le32(meta->data+8)>101)return fail(e,"Catalogo excede limite suportado");
    memcpy(entry,name,strlen(name));memcpy(entry+64,"Adicionado por SCL Temas",24);wl32(entry+192,index);wl32(entry+196,1);
    for(i=0;i<r->count;i++){RFile*f=&r->files[i];if(strncmp(f->name,"ContentInfoArchive_",19))continue;
        if(f->size<8||le32(f->data)!=1||le32(f->data+4)+1!=(f->size-8)/200||(f->size-8)%200)return fail(e,"Catalogo de idioma invalido");
        {size_t j;U8*p;for(j=8;j<f->size;j+=200)if(le32(f->data+j+192)==index)return fail(e,"Indice ja existe no catalogo");
        p=realloc(f->data,f->size+200);if(!p)return fail(e,"Memoria insuficiente");f->data=p;memcpy(p+f->size,entry,200);f->size+=200;wl32(p+4,le32(p+4)+1);}langs++;
    }
    if(!langs||langs!=le32(meta->data+0x30))return fail(e,"Idiomas do catalogo incompletos");
    wl32(meta->data+4,le32(meta->data+4)+1);wl32(meta->data+8,le32(meta->data+8)+1);
    snprintf(path,sizeof(path),"icons/%u.icn",index);return rput(r,path,icon,4608,e);
}
static int put(FILE*f,const void*p,size_t n){return fwrite(p,1,n,f)==n;}
static FILE *exclusive(const char *path){int fd=open(path,O_CREAT|O_EXCL|O_WRONLY|O_BINARY,0600);FILE*f;if(fd<0)return NULL;f=fdopen(fd,"wb");if(!f)close(fd);return f;}
static int padto(FILE*f,size_t alignment){static const U8 z[64]={0};long pos=ftell(f);size_t n;if(pos<0)return 0;n=al((size_t)pos,alignment)-(size_t)pos;return put(f,z,n);}
static int copypart(FILE*in,FILE*out,uint64_t off,uint64_t size){U8 b[32768];if(off>LONG_MAX||fseek(in,(long)off,SEEK_SET))return 0;
    while(size){size_t n=size>sizeof(b)?sizeof(b):(size_t)size;if(fread(b,1,n,in)!=n||!put(out,b,n))return 0;size-=n;}return 1;}
static uint32_t contentid(const U8 hash[32],TTPackage*p){uint32_t id=be32(hash);unsigned i;int found;
    do{found=0;for(i=0;i<p->count;i++)if(p->contents[i].id==id)found=1;if(found)id++;}while(found);return id;}
static int rebuild_old(FILE*in,const TTContent*c,const U8*header,U8**out,size_t*outn,char*e){
    U8*old=loadpart(in,c->offset,(size_t)c->size);RFiles*files;int rc;
    if(!old)return fail(e,"Erro lendo tema anterior");
    files=rparse(old+le32(old+0x1B0)*512,le32(old+0x1B4)*512,e);free(old);if(!files)return -1;
    rc=ncchbuild(files,header,c->index,out,outn,e);rfree(files);return rc;
}
static int rebuild(const char*base,const char*folder,const char*dest,int repair,char*e) {
    TTPackage pkg;FILE*in=NULL,*out=NULL,*exists=NULL;RFiles*control=NULL,*theme=NULL;U8*ctrl=NULL,*newctrl=NULL,*newtheme=NULL,*tmd=NULL,*tik=NULL,*cert=NULL;
    size_t ctrl_n=0,nc=0,nt=0,tmdn,tikn;U8 icon[4608],header[0x2020],template_header[512],hash[32];char name[64];uint16_t index=1;unsigned i,j;uint64_t total,target;int rc=-1,created=0;unsigned outcount;
    if(!strcmp(base,dest))return fail(e,"Destino deve ser diferente da base");
    exists=fopen(dest,"rb");if(exists){fclose(exists);return fail(e,"Destino ja existe; nenhum arquivo foi alterado");}
    verify_start=0;verify_span=20;tt_progress("Verificando base",0);
    if(tt_verify(base,e)||tt_inspect(base,&pkg,e))return -1;
    if(!repair&&pkg.count>=TT_MAX_CONTENTS)return fail(e,"Limite de 100 temas atingido");
    target=pkg.title_id;
    if(repair){
        if((target&255)!=0xFE&&(target&255)!=9)return fail(e,"Reparo suporta somente os catalogos FE e 09");
        target=(target&~255ULL)|9;
    }
    outcount=pkg.count+(repair?0:1);
    if(pkg.version==65535)return fail(e,"Versao TMD esgotada");
    for(;;){int used=0;for(i=0;i<pkg.count;i++)if(pkg.contents[i].index==index)used=1;if(!used)break;if(++index>1023)return fail(e,"Sem indice livre");}
    in=fopen(base,"rb");if(!in)return fail(e,"Erro abrindo base");
    ctrl_n=(size_t)pkg.contents[0].size;ctrl=loadpart(in,pkg.contents[0].offset,ctrl_n);if(!ctrl)goto io;
    memcpy(template_header,ctrl,512);control=rparse(ctrl+le32(ctrl+0x1B0)*512,le32(ctrl+0x1B4)*512,e);free(ctrl);ctrl=NULL;if(!control)goto done;
    if(catalog_normalize(control,e))goto done;
    wl64(template_header+0x118,target);wl64(template_header+0x108,target);
    if(repair){const char*product=((uint32_t)target&0xFFFFFF00)==0x8200?"CTR-M-HMMJ-09":((uint32_t)target&0xFFFFFF00)==0x8F00?"CTR-M-HMME-09":"CTR-M-HMMP-09";
        memset(template_header+0x150,0,16);memcpy(template_header+0x150,product,14);}
    if(!repair){
        theme=calloc(1,sizeof(*theme));if(!theme)goto io;
        tt_progress("Extraindo tema",20);
        if(themefiles(folder,theme,name,icon,e)||catalog_add(control,index,name,icon,e))goto done;
        if(ncchbuild(theme,template_header,index,&newtheme,&nt,e))goto done;
    }
    tt_progress("Montando catalogo",35);
    if(ncchbuild(control,template_header,0,&newctrl,&nc,e))goto done;
    for(i=1;!repair&&i<pkg.count;i++){U8 oldheader[512];if(!readat(in,pkg.contents[i].offset,oldheader,512))goto io;
        if(!memcmp(newtheme+0x1E0,oldheader+0x1E0,32)){fail(e,"Este tema ja esta no pacote");goto done;}}
    /* Read ticket/certificates from the user's template; no Nintendo assets are bundled. */
    cert=loadpart(in,pkg.cert_offset,pkg.cert_size);tik=loadpart(in,pkg.ticket_offset,pkg.ticket_size);tmdn=0xB04+outcount*48;tmd=calloc(1,tmdn);
    if(!cert||!tik||!tmd||!readat(in,pkg.tmd_offset,tmd,0xB04+pkg.count*48))goto io;
    /* Known makerom/HTT rights layout only. Unknown layouts fail before writing. */
    if(pkg.ticket_size!=0x350||be32(tik+0x2A4)!=0x10014||be32(tik+0x2A8)!=0xAC||be32(tik+0x2B8)!=0x28||be32(tik+0x2BC)!=1||be32(tik+0x2C0)!=0x84||be32(tik+0x2CC)!=0){fail(e,"Layout de ticket HTT nao suportado");goto done;}
    tikn=pkg.ticket_size;if(!repair)tik[0x2D0+index/8]|=(U8)(1<<(index%8));wb64(tik+0x1DC,target);wb64(tmd+0x18C,target);wb16(tik+0x1E6,pkg.version+1);memset(tik+4,0xFF,256);
    memset(tmd+4,0xFF,256);wb16(tmd+0x1DC,pkg.version+1);wb16(tmd+0x1DE,(uint16_t)outcount);
    tt_sha256(newctrl,nc,hash);pkg.contents[0].id=contentid(hash,&pkg);wb32(tmd+0xB04,pkg.contents[0].id);wb64(tmd+0xB04+8,nc);memcpy(tmd+0xB04+16,hash,32);
    if(!repair){U8*r=tmd+0xB04+pkg.count*48;tt_sha256(newtheme,nt,hash);wb32(r,contentid(hash,&pkg));wb16(r+4,index);wb16(r+6,0x4000);wb64(r+8,nt);memcpy(r+16,hash,32);}
    if(repair)for(i=1;i<pkg.count;i++){
        U8*buf=NULL;size_t size=0;if(rebuild_old(in,&pkg.contents[i],template_header,&buf,&size,e))goto done;
        wb64(tmd+0xB04+i*48+8,size);tt_sha256(buf,size,tmd+0xB04+i*48+16);free(buf);
    }
    memset(tmd+0x204,0,0x900);wb16(tmd+0x206,(uint16_t)outcount);tt_sha256(tmd+0xB04,outcount*48,tmd+0x208);tt_sha256(tmd+0x204,0x900,tmd+0x1E4);
    memset(header,0,sizeof(header));wl32(header,0x2020);wl32(header+8,pkg.cert_size);wl32(header+12,(uint32_t)tikn);wl32(header+16,(uint32_t)tmdn);
    total=nc+nt;for(i=1;i<pkg.count;i++)total+=be64(tmd+0xB04+i*48+8);wl64(header+24,total);
    for(i=0;i<pkg.count;i++){j=pkg.contents[i].index;header[0x20+j/8]|=(U8)(0x80>>(j%8));}if(!repair)header[0x20+index/8]|=(U8)(0x80>>(index%8));
    out=exclusive(dest);if(!out){fail(e,"Nao foi possivel criar candidato: %s",strerror(errno));goto done;}created=1;
    if(!put(out,header,sizeof(header))||!padto(out,64)||!put(out,cert,pkg.cert_size)||!padto(out,64)||!put(out,tik,tikn)||!padto(out,64)||!put(out,tmd,tmdn)||!padto(out,64)||!put(out,newctrl,nc))goto io;
    for(i=1;i<pkg.count;i++){
        if(repair){U8*buf=NULL;size_t size=0;int ok;if(rebuild_old(in,&pkg.contents[i],template_header,&buf,&size,e))goto done;
            ok=put(out,buf,size);free(buf);if(!ok)goto io;
        }else if(!copypart(in,out,pkg.contents[i].offset,pkg.contents[i].size))goto io;
        tt_progress("Copiando catalogo",35+15*i/pkg.count);
    }
    if((!repair&&!put(out,newtheme,nt))||fflush(out)||fsync(fileno(out)))goto io;
    if(fclose(out)){out=NULL;goto io;}out=NULL;
    verify_start=50;verify_span=15;tt_progress("Validando candidato",50);
    if(tt_verify(dest,e))goto done;rc=0;goto done;
io:fail(e,"Erro de leitura/escrita ou memoria insuficiente");
done:if(in)fclose(in);if(out)fclose(out);free(ctrl);free(newctrl);free(newtheme);free(tmd);free(tik);free(cert);if(control)rfree(control);if(theme)rfree(theme);
    if(rc&&created)remove(dest);return rc;
}

int tt_add(const char*base,const char*folder,const char*dest,char*e){return rebuild(base,folder,dest,0,e);}
int tt_repair(const char*base,const char*dest,char*e){return rebuild(base,NULL,dest,1,e);}
