#include "cleanup.h"
#include <ctype.h>
#include <string.h>
int e4_can_delete_input(const char*path){char p[1024];size_t i,n=strlen(path);const char*component;
    if(n<10||n>=sizeof(p))return 0;
    for(i=0;i<=n;i++){if(path[i]=='\\')return 0;p[i]=(char)tolower((unsigned char)path[i]);}
    if(strncmp(p,"sdmc:/",6)||strcmp(p+n-4,".cia"))return 0;
    if(!strncmp(p,"sdmc:/3ds/scl-temas/",19)||!strncmp(p,"sdmc:/nintendo 3ds/",18))return 0;
    component=p+6;
    while(*component){const char*end=strchr(component,'/');size_t len=end?(size_t)(end-component):strlen(component);
        if(!len||(len==1&&component[0]=='.')||(len==2&&component[0]=='.'&&component[1]=='.'))return 0;
        if(!end)break;component=end+1;
    }
    return 1;
}
