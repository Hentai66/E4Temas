#include "tt.h"
#include "import.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <limits.h>
#include "miniz_tinfl.h"
#define STBI_ONLY_PNG
#define STBI_MAX_DIMENSIONS 512
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#define STBI_NO_SIMD
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "stb_image.h"
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

static unsigned u16(const unsigned char*p){return p[0]|((unsigned)p[1]<<8);}
static uint32_t u32(const unsigned char*p){return u16(p)|((uint32_t)u16(p+2)<<16);}
static uint64_t u64(const unsigned char*p){return u32(p)|((uint64_t)u32(p+4)<<32);}
static uint32_t b32(const unsigned char*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint64_t b64(const unsigned char*p){return ((uint64_t)b32(p)<<32)|b32(p+4);}
static size_t align64(size_t n){return(n+63)&~(size_t)63;}
static int readat(FILE*f,size_t off,void*p,size_t n){return off<=LONG_MAX&&!fseek(f,(long)off,SEEK_SET)&&fread(p,1,n,f)==n;}
static int zipread(FILE*f,size_t base,size_t off,void*p,size_t n){return off<=SIZE_MAX-base&&readat(f,base+off,p,n);}
/* One table lookup per byte instead of eight bit iterations. */
static uint32_t crc32(const unsigned char*p,size_t n){
    static uint32_t table[256];static int ready;uint32_t c=0xFFFFFFFF;size_t i;
    if(!ready){unsigned k,j;for(k=0;k<256;k++){uint32_t v=k;for(j=0;j<8;j++)v=(v>>1)^(0xEDB88320U&((uint32_t)0-(v&1)));table[k]=v;}ready=1;}
    for(i=0;i<n;i++)c=(c>>8)^table[(c^p[i])&255];return ~c;
}
static int safe_name(const char*name){const char*p=name;if(!*p||*p=='/'||strchr(p,'\\')||strchr(p,':'))return 0;
    while(*p){const char*end=strchr(p,'/');size_t n=end?(size_t)(end-p):strlen(p);if((n==2&&p[0]=='.'&&p[1]=='.')||(n==1&&p[0]=='.'))return 0;if(!end)break;p=end+1;}return 1;}
typedef struct {size_t local,compressed,size;uint32_t crc;unsigned method,flags;char name[512];} ZipFile;

static unsigned char*zip_asset(FILE*f,size_t base,size_t end,const char*wanted,size_t*outn,size_t maximum){
    unsigned char tail[65557],central[46],local[30],*compressed=NULL,*output=NULL;size_t tailn,eocd,cd,cdsize,cursor,cdend;unsigned entries,i,bodies=0,matches=0;char prefix[512]={0};ZipFile chosen={0};
    if(end<22||end>20*1024*1024)return NULL;
    tailn=end>sizeof(tail)?sizeof(tail):end;if(!zipread(f,base,end-tailn,tail,tailn))return NULL;
    eocd=tailn-22;
    for(;;){if(u32(tail+eocd)==0x06054B50&&eocd+22+u16(tail+eocd+20)==tailn)break;if(!eocd)return NULL;eocd--;}
    if(u16(tail+eocd+4)||u16(tail+eocd+6)||u16(tail+eocd+8)!=u16(tail+eocd+10))return NULL;
    entries=u16(tail+eocd+10);cdsize=u32(tail+eocd+12);cd=u32(tail+eocd+16);
    if(!entries||entries>256||cd>(size_t)end||cdsize>(size_t)end-cd||cd+cdsize>(size_t)end-tailn+eocd)return NULL;cdend=cd+cdsize;
    /* First establish the unique theme directory; then locate only that directory's assets. */
    for(i=0;i<entries;i++){char name[512];size_t nl,xl,cl;const char*basename;cursor=(i?cursor:cd);
        if(cursor>cdend||46>cdend-cursor||!zipread(f,base,cursor,central,46)||u32(central)!=0x02014B50)return NULL;
        nl=u16(central+28);xl=u16(central+30);cl=u16(central+32);if(!nl||nl>=sizeof(name)||46+nl+xl+cl>cdend-cursor)return NULL;
        if(!zipread(f,base,cursor+46,name,nl)||memchr(name,0,nl))return NULL;name[nl]=0;if(!safe_name(name))return NULL;
        basename=strrchr(name,'/');basename=basename?basename+1:name;if(!strcmp(basename,"body_LZ.bin")){size_t len=(size_t)(basename-name);if(++bodies>1)return NULL;memcpy(prefix,name,len);prefix[len]=0;}
        cursor+=46+nl+xl+cl;
    }
    if(bodies!=1||cursor!=cdend)return NULL;cursor=cd;
    for(i=0;i<entries;i++){char name[512];size_t nl,xl,cl;
        if(!zipread(f,base,cursor,central,46))return NULL;nl=u16(central+28);xl=u16(central+30);cl=u16(central+32);
        if(!zipread(f,base,cursor+46,name,nl))return NULL;name[nl]=0;
        if(!strncmp(name,prefix,strlen(prefix))&&!strcmp(name+strlen(prefix),wanted)){
            if(++matches>1)return NULL;strcpy(chosen.name,name);chosen.flags=u16(central+8);chosen.method=u16(central+10);chosen.crc=u32(central+16);chosen.compressed=u32(central+20);chosen.size=u32(central+24);chosen.local=u32(central+42);
        }cursor+=46+nl+xl+cl;
    }
    if(matches!=1||chosen.flags&(1|64)||chosen.size>maximum||chosen.compressed>8*1024*1024||chosen.local>cd||30>cd-chosen.local)return NULL;
    if(!zipread(f,base,chosen.local,local,30)||u32(local)!=0x04034B50||u16(local+6)!=chosen.flags||u16(local+8)!=chosen.method)return NULL;
    {char name[512];size_t nl=u16(local+26),extra=u16(local+28),dataoff=chosen.local+30+nl+extra;
        if(nl!=strlen(chosen.name)||!zipread(f,base,chosen.local+30,name,nl)||memcmp(name,chosen.name,nl)||dataoff>cd||chosen.compressed>cd-dataoff)return NULL;
        /* Probe validates bounded ZIP metadata without inflating it. */
        if(!outn){if(!chosen.size||(chosen.method!=0&&chosen.method!=8))return NULL;return malloc(1);}
        compressed=malloc(chosen.compressed?chosen.compressed:1);output=malloc(chosen.size?chosen.size:1);if(!compressed||!output)goto bad;
        if(!zipread(f,base,dataoff,compressed,chosen.compressed))goto bad;
        if(chosen.method==0){if(chosen.size!=chosen.compressed)goto bad;memcpy(output,compressed,chosen.size);}
        else if(chosen.method==8){if(tinfl_decompress_mem_to_mem(output,chosen.size,compressed,chosen.compressed,0)!=chosen.size)goto bad;}
        else goto bad;
    }
    if(crc32(output,chosen.size)!=chosen.crc)goto bad;free(compressed);*outn=chosen.size;return output;
bad:free(compressed);free(output);return NULL;
}
/* Read the unique embedded ZIP from a plaintext hShop-style installer CIA.
 * Its executable code is NEVER loaded, installed, or run. No keys/decryption.
 */
static unsigned char*cia_asset(FILE*f,const char*name,size_t*outn,size_t maximum){
    unsigned char h[32],tmd[0x140],chunk[48],ncch[512],ivfc[0x60],l3[40],record[32];
    size_t tik,tm,co,rom,rs,l3off,fs,fl,fd,pos,zipoff=0,zipsize=0;uint64_t content_size;long end;unsigned matches=0;
    if(fseek(f,0,SEEK_END)||(end=ftell(f))<0||end>32*1024*1024||!readat(f,0,h,32)||u32(h)!=0x2020)return NULL;
    if(u32(h+8)>0x10000||u32(h+12)>0x10000||u32(h+16)>0x10000)return NULL;
    tik=align64(align64(0x2020)+u32(h+8));tm=align64(tik+u32(h+12));co=align64(tm+u32(h+16));
    if(tm>(size_t)end||u32(h+16)>(size_t)end-tm||u32(h+16)<0xB34||!readat(f,tm,tmd,sizeof(tmd))||b32(tmd)!=0x10004)return NULL;
    if(!readat(f,tm+0xB04,chunk,48)||u16(chunk+4)||(chunk[7]&1))return NULL;content_size=b64(chunk+8);
    if(co>(size_t)end||content_size>(size_t)end-co||content_size<512||!readat(f,co,ncch,512)||memcmp(ncch+0x100,"NCCH",4)||!(ncch[0x18F]&4)||ncch[0x18E])return NULL;
    rom=(size_t)u32(ncch+0x1B0)*512;rs=(size_t)u32(ncch+0x1B4)*512;
    if(rom>content_size||rs>content_size-rom||rs<0x1000||!readat(f,co+rom,ivfc,sizeof(ivfc))||memcmp(ivfc,"IVFC",4)||u32(ivfc+8)>0x100000)return NULL;
    l3off=(0x60+u32(ivfc+8)+4095)&~(size_t)4095;
    if(l3off>rs||40>rs-l3off||!readat(f,co+rom+l3off,l3,40)||u32(l3)!=40)return NULL;
    fs=u32(l3+0x1C);fl=u32(l3+0x20);fd=u32(l3+0x24);
    if(fs>rs-l3off||fl>rs-l3off-fs||fd>rs-l3off)return NULL;
    for(pos=0;pos<fl;){size_t nl,step,j;uint64_t off,sz;char filename[512];
        if(32>fl-pos||!readat(f,co+rom+l3off+fs+pos,record,32))return NULL;
        nl=u32(record+28);off=u64(record+8);sz=u64(record+16);step=32+((nl+3)&~(size_t)3);
        if(nl>1022||(nl&1)||step>fl-pos||off>rs-l3off-fd||sz>rs-l3off-fd-off)return NULL;
        {unsigned char encoded[1024];if(!readat(f,co+rom+l3off+fs+pos+32,encoded,nl))return NULL;
            for(j=0;j<nl/2;j++){if(encoded[j*2+1]||!encoded[j*2])return NULL;filename[j]=(char)encoded[j*2];}filename[nl/2]=0;}
        if(nl>=8&&(!strcmp(filename+nl/2-4,".zip")||!strcmp(filename+nl/2-4,".ZIP"))){if(++matches>1)return NULL;zipoff=co+rom+l3off+fd+(size_t)off;zipsize=(size_t)sz;}
        pos+=step;
    }
    if(matches!=1)return NULL;return zip_asset(f,zipoff,zipsize,name,outn,maximum);
}
unsigned char *tt_asset(const char*input,const char*name,size_t*size,size_t maximum){
    size_t len=strlen(input);FILE*f;unsigned char*p=NULL;char path[1100];long n;
    if(len>=4&&(!strcmp(input+len-4,".zip")||!strcmp(input+len-4,".ZIP"))){f=fopen(input,"rb");if(!f)return NULL;if(!fseek(f,0,SEEK_END)&&(n=ftell(f))>=0)p=zip_asset(f,0,(size_t)n,name,size,maximum);fclose(f);return p;}
    if(len>=4&&(!strcmp(input+len-4,".cia")||!strcmp(input+len-4,".CIA"))){f=fopen(input,"rb");if(!f)return NULL;p=cia_asset(f,name,size,maximum);fclose(f);return p;}
    if(snprintf(path,sizeof(path),"%s/%s",input,name)>=(int)sizeof(path))return NULL;f=fopen(path,"rb");if(!f)return NULL;
    if(!fseek(f,0,SEEK_END)&&(n=ftell(f))>=0&&(size_t)n<=maximum){p=malloc(n?n:1);if(p&&!readat(f,0,p,(size_t)n)){free(p);p=NULL;}if(p)*size=(size_t)n;}fclose(f);return p;
}
int tt_png_icon(const unsigned char*png,size_t n,unsigned char icon[4608]){
    int w,h,c;unsigned x,y;unsigned char*p;
    if(n>1024*1024||!stbi_info_from_memory(png,(int)n,&w,&h,&c)||w!=48||h!=48)return 0;
    p=stbi_load_from_memory(png,(int)n,&w,&h,&c,4);if(!p)return 0;
    for(y=0;y<48;y++)for(x=0;x<48;x++){
        /* PICA200: row-major 8x8 tiles with Morton order inside each tile. */
        unsigned xx=x&7,yy=y&7,m=(xx&1)|((yy&1)<<1)|((xx&2)<<1)|((yy&2)<<2)|((xx&4)<<2)|((yy&4)<<3);
        unsigned off=((y/8)*6+x/8)*64+m;unsigned char*rgba=p+(y*48+x)*4;unsigned a=rgba[3];
        unsigned red=rgba[0]*a/255,green=rgba[1]*a/255,blue=rgba[2]*a/255;unsigned rgb=((red>>3)<<11)|((green>>2)<<5)|(blue>>3);
        icon[off*2]=(unsigned char)rgb;icon[off*2+1]=(unsigned char)(rgb>>8);
    }stbi_image_free(p);return 1;
}

int tt_is_theme_cia(const char*path){FILE*f=fopen(path,"rb");unsigned char*p;if(!f)return 0;
    p=cia_asset(f,"body_LZ.bin",NULL,0x150000);fclose(f);if(!p)return 0;free(p);return 1;}
