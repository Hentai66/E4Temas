/* E4Temas: experimental on-console incremental native-theme package manager. */
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>
#include "tt.h"
#include "startup.h"
#include "ui.h"
#include "cleanup.h"
#include "sha256.h"

#define ROOT "sdmc:/3ds/scl-temas"
#define BASE ROOT "/base.cia"
#define CURRENT ROOT "/current.cia"
#define CANDIDATE ROOT "/candidate.cia"
#define JOURNAL ROOT "/pending.txt"
#define LOG ROOT "/log.txt"
#define MAX_CHOICES 512
typedef struct {char label[256];char path[1024];int directory;} Choice;
static Choice choices[MAX_CHOICES];
static unsigned choice_count,hidden_cias;
typedef struct {char path[1024];unsigned char hash[32];} QueueItem;
static QueueItem queue[100];static unsigned queue_count;
static int light_theme,batch_auto;static unsigned pending_additions=1;
static unsigned char previous_top[400*240*3];static int have_previous;
static void bottom_begin(const char*title){ui_surface(gfxGetFramebuffer(GFX_BOTTOM,GFX_LEFT,NULL,NULL),320);ui_clear();ui_rect(0,0,320,38,ui_colors.panel);ui_text(12,11,title,ui_colors.text,37);}
static void wrapped(int y,const char*s){char line[39];int n=0;while(*s&&y<208){
    if(*s=='\n'||n==37){line[n]=0;ui_text(12,y,line,ui_colors.text,37);y+=17;n=0;if(*s=='\n')s++;}
    else line[n++]=*s++;
}if(n){line[n]=0;ui_text(12,y,line,ui_colors.text,37);}}

void e4_intro(void);
/* Bounded format parsing and hashing use up to ~100 KiB of nested stack. */
u32 __stacksize__ = 256*1024;
static char builtin_base[128];
static char current_dir[1024]="sdmc:/";

static int exists(const char*name){struct stat s;return !stat(name,&s);}
static void logline(const char*message){FILE*f=fopen(LOG,"ab");if(f){fprintf(f,"%s\n",message);fflush(f);fsync(fileno(f));fclose(f);}}
static void frame(void){gfxFlushBuffers();gfxSwapBuffers();gspWaitForVBlank();}
static u32 key(void){hidScanInput();return hidKeysDown();}
static unsigned job_number=1,job_total=1,job_percent;static u64 last_progress;static int new_model;
static void progress_ui(const char*stage,unsigned percent){char text[100];u64 now=osGetTime();unsigned overall;
    if(percent>100)percent=100;
    if(percent<job_percent)percent=job_percent;
    if(percent!=100&&now-last_progress<100&&percent==job_percent)return;
    if(percent!=100&&now-last_progress<100)return;
    job_percent=percent;last_progress=now;
    overall=((job_number-1)*100+percent)/job_total;
    bottom_begin("Progresso da instalacao");
    snprintf(text,sizeof(text),"Tema %u de %u | 1 por vez",job_number,job_total);ui_text(12,48,text,ui_colors.text,37);
    ui_text(12,72,stage,ui_colors.text,37);
    ui_rect(12,101,296,28,ui_colors.muted);ui_rect(14,103,292,24,ui_colors.panel);
    ui_rect(14,103,(int)(292*overall/100),24,ui_colors.accent);
    snprintf(text,sizeof(text),"Total: %u%% | tema atual: %u%%",overall,percent);ui_text(12,139,text,ui_colors.text,37);
    snprintf(text,sizeof(text),"Extraidos %u | instalados %u",job_number-1+(percent>=35),job_number-1+(percent==100));ui_text(12,162,text,ui_colors.text,37);
    ui_text(12,185,new_model?"New 3DS: aceleracao ativa":"Old 3DS: modo compativel",ui_colors.muted,37);
    ui_text(12,218,"Nao desligue nem retire o SD.",ui_colors.text,37);frame();
}
static void wait_b(void){while(aptMainLoop()){if(key()&(KEY_B|KEY_START))break;frame();}}
static void message(const char*title,const char*detail){bottom_begin(title);wrapped(48,detail);ui_text(12,220,"B: voltar",ui_colors.muted,37);frame();wait_b();}
static int cmp_choice(const void*a,const void*b){const Choice*x=a,*y=b;if(x->directory!=y->directory)return y->directory-x->directory;return strcmp(x->label,y->label);}
static void scan(const char*folder){DIR*d=opendir(folder);struct dirent*de;if(!d)return;
    while((de=readdir(d))&&choice_count<MAX_CHOICES){char path[1024],body[1100];struct stat st;Choice*c;
        if(de->d_name[0]=='.')continue;if(snprintf(path,sizeof(path),"%s%s%s",folder,folder[strlen(folder)-1]=='/'?"":"/",de->d_name)>=(int)sizeof(path))continue;
        if(stat(path,&st))continue;
        if(S_ISDIR(st.st_mode)){snprintf(body,sizeof(body),"%s/body_LZ.bin",path);}
        else{size_t len=strlen(path);if(len<4||(strcmp(path+len-4,".zip")&&strcmp(path+len-4,".ZIP")&&strcmp(path+len-4,".cia")&&strcmp(path+len-4,".CIA")))continue;}
        if(S_ISREG(st.st_mode)){size_t n=strlen(path);if(n>=4&&!strcasecmp(path+n-4,".cia")&&!tt_is_theme_cia(path)){hidden_cias++;continue;}}
        c=&choices[choice_count++];c->directory=S_ISDIR(st.st_mode)&&!exists(body);snprintf(c->label,sizeof(c->label),"%s",de->d_name);snprintf(c->path,sizeof(c->path),"%s",path);
    }closedir(d);}
static void rescan(void){choice_count=0;hidden_cias=0;scan(current_dir);qsort(choices,choice_count,sizeof(Choice),cmp_choice);}
static void parent_dir(void){size_t n=strlen(current_dir);char*slash;if(n<=6)return;if(current_dir[n-1]=='/')current_dir[n-1]=0;slash=strrchr(current_dir,'/');if(slash&&slash>current_dir+5)*slash=0;else strcpy(current_dir,"sdmc:/");}
static int cfw_ok(char*e){s64 value=0;Result r=svcGetSystemInfo(&value,0x10000,0);
    if(R_FAILED(r)||(u32)value<SYSTEM_VERSION(13,4,0)){snprintf(e,256,"Requer Luma3DS 13.4 ou superior.");return 0;}return 1;}
static const char*select_base(void){u8 region;Result r;if(exists(CURRENT))return CURRENT;if(exists(BASE))return BASE;
    r=cfguInit();if(R_FAILED(r))return BASE;r=CFGU_SecureInfoGetRegion(&region);cfguExit();if(R_FAILED(r))return BASE;
    snprintf(builtin_base,sizeof(builtin_base),"romfs:/%s.cia",region==CFG_REGION_JPN?"JPN":region==CFG_REGION_USA?"USA":region==CFG_REGION_EUR?"EUR":"unsupported");return builtin_base;}
static int region_ok(uint64_t title,char*e){u8 region;uint32_t expected=0;Result r=cfguInit();if(R_FAILED(r)){snprintf(e,256,"CFGU: %08lX",(u32)r);return 0;}
    r=CFGU_SecureInfoGetRegion(&region);cfguExit();if(R_FAILED(r)){snprintf(e,256,"Nao foi possivel ler a regiao.");return 0;}
    if(region==CFG_REGION_JPN)expected=0x8200;if(region==CFG_REGION_USA)expected=0x8F00;if(region==CFG_REGION_EUR)expected=0x9800;
    if(((uint32_t)title&0xFFFFFF00)!=expected||!expected){snprintf(e,256,"Regiao do pacote difere da regiao do console (JPN/USA/EUR).");return 0;}
    /* Keep the primary purchased-theme DLC title out of this experimental tool. */
    if(!(title&255)){snprintf(e,256,"Pacote usa o titulo primario de temas comprados. Requer base HTT com variacao separada (ID final diferente de 00).");return 0;}return 1;}

/* Compare every installed content before replacing ANY package. AMAPP is read-only. */
static int installed_matches(const TTPackage*p,int allow_absent,char*e){Result r;u64*ids=NULL;u32 count=0,read=0,i,total=0;int found=0,ok=0;
    r=amInit();if(R_FAILED(r)){snprintf(e,256,"AM: %08lX",(u32)r);return 0;}
    r=AM_GetTitleCount(MEDIATYPE_SD,&count);if(R_FAILED(r)||count>8192)goto normal_error;
    ids=calloc(count?count:1,sizeof(u64));if(!ids){snprintf(e,256,"Memoria insuficiente");amExit();return 0;}
    r=AM_GetTitleList(&read,MEDIATYPE_SD,count,ids);if(R_FAILED(r)||read!=count)goto normal_error;
    for(i=0;i<count;i++)if(ids[i]==p->title_id){AM_TitleEntry info;found=1;r=AM_GetTitleInfo(MEDIATYPE_SD,1,&ids[i],&info);if(R_FAILED(r)||info.version!=p->version){snprintf(e,256,"Versao instalada difere da base. Nao sobrescrito.");free(ids);amExit();return 0;}}
    amExit();if(!found&&!allow_absent){free(ids);snprintf(e,256,"Titulo gerenciado nao esta instalado.");return 0;}
    r=amAppInit();if(R_FAILED(r)){free(ids);snprintf(e,256,"AMAPP: %08lX",(u32)r);return 0;}
    for(i=0;i<count;i++)if((ids[i]&0xFFFFFFFFFFFFFF00ULL)==(p->title_id&0xFFFFFFFFFFFFFF00ULL)){
        AM_ContentInfo*infos=NULL;u32 n=0,nread=0,j,installed=0;
        r=AMAPP_GetDLCContentInfoCount(&n,MEDIATYPE_SD,ids[i]);if(R_FAILED(r)||n>4096)goto app_error;
        infos=calloc(n?n:1,sizeof(*infos));if(!infos){snprintf(e,256,"Memoria insuficiente");goto end;}
        r=AMAPP_ListDLCContentInfos(&nread,MEDIATYPE_SD,ids[i],n,0,infos);
        if(R_FAILED(r)||nread!=n){free(infos);goto app_error;}
        for(j=0;j<n;j++)if(infos[j].flags&1){unsigned k;int match=0;installed++;if(infos[j].index&&!((p->title_id&255)==9&&(ids[i]&255)==0xFE))total++;
            if(ids[i]!=p->title_id)continue;
            for(k=0;k<p->count;k++)if(p->contents[k].index==infos[j].index&&p->contents[k].id==infos[j].contentId&&p->contents[k].size==infos[j].size)match=1;
            if(!match){free(infos);snprintf(e,256,"A base nao contem todos os temas instalados. Nao sobrescrito.");goto end;}
        }
        free(infos);if(ids[i]==p->title_id&&installed!=p->count){snprintf(e,256,"Base e pacote instalado tem conteudos diferentes.");goto end;}
    }
    if(total+(allow_absent?(found?pending_additions:p->count-1+pending_additions):0)>100){snprintf(e,256,"A adicao ultrapassaria 100 temas instalados.");goto end;}ok=1;goto end;
app_error:snprintf(e,256,"Falha consultando temas instalados: %08lX",(u32)r);
end:amExit();free(ids);return ok;
normal_error:snprintf(e,256,"Falha consultando titulos: %08lX",(u32)r);free(ids);amExit();return 0;
}
/* Refuse to take over another manager's existing 09 package. */
static int target_absent(uint64_t title,char*e){u32 n=0,read=0,i;u64*ids;Result r=amInit();int ok=0;
    if(R_FAILED(r)){snprintf(e,256,"AM indisponivel: %08lX",(u32)r);return 0;}
    r=AM_GetTitleCount(MEDIATYPE_SD,&n);if(R_FAILED(r)||n>8192){amExit();snprintf(e,256,"Falha consultando destino");return 0;}
    ids=calloc(n?n:1,sizeof(u64));if(!ids){amExit();snprintf(e,256,"Memoria insuficiente");return 0;}
    r=AM_GetTitleList(&read,MEDIATYPE_SD,n,ids);
    if(R_SUCCEEDED(r)&&read==n){ok=1;for(i=0;i<n;i++)if(ids[i]==title)ok=0;}
    free(ids);amExit();if(!ok)snprintf(e,256,"Destino 09 existente ou consulta falhou. Nada sobrescrito. Preserve sua colecao HTT e consulte o relatorio.");return ok;
}
static int enough_space(uint64_t required,char*e){struct statvfs s;if(statvfs("sdmc:/",&s)){snprintf(e,256,"Nao foi possivel verificar espaco no SD.");return 0;}
    if((uint64_t)s.f_bavail*s.f_frsize<required){snprintf(e,256,"Espaco insuficiente no SD. Libere ao menos %llu MiB.",(unsigned long long)((required+1048575)/1048576));return 0;}return 1;}
static int confirmation(void){bottom_begin("Confirmar instalacao");
    wrapped(49,"O catalogo anterior sera guardado.\n\nNao desligue nem retire o SD.\n\nL + R + A: instalar\nB: cancelar");frame();
    while(aptMainLoop()){u32 down=key(),held=hidKeysHeld();if(down&KEY_B)return 0;if((down&KEY_A)&&(held&KEY_L)&&(held&KEY_R))return 1;gspWaitForVBlank();}return 0;}
static void discard_candidate(void){if(exists(JOURNAL)){message("Recuperacao pendente","Use R e depois R para verificar o estado.");return;}
    if(!exists(CANDIDATE)){message("Sem candidato","Nenhuma CIA candidata para descartar.");return;}
    bottom_begin("Descartar candidato?");wrapped(49,"Isso nao desinstala temas.\n\nA: descartar candidate.cia\nB: cancelar");frame();
    while(aptMainLoop()){u32 down=key();if(down&KEY_B)return;if(down&KEY_A){if(remove(CANDIDATE))message("Erro","Nao foi possivel remover candidate.cia.");return;}gspWaitForVBlank();}}
static void recover(void){TTPackage candidate,old;char e[256],backup[256];const char*previous;const char*pending_source=exists(CANDIDATE)?CANDIDATE:CURRENT;
    if(!exists(JOURNAL)){message("Sem recuperacao pendente","Nenhuma operacao interrompida registrada.");return;}
    if(tt_verify(pending_source,e)||tt_inspect(pending_source,&candidate,e)||!cfw_ok(e)||!region_ok(candidate.title_id,e)){message("Verificacao de recuperacao",e);return;}
    if(installed_matches(&candidate,0,e)){
        if(!strcmp(pending_source,CANDIDATE)&&exists(CURRENT)){message("Estado ambiguo","current.cia e candidate.cia existem. Preserve todos os arquivos e consulte o README.");return;}
        if((strcmp(pending_source,CURRENT)&&rename(CANDIDATE,CURRENT))||remove(JOURNAL)){message("Erro de finalizacao","Arquivos preservados; nao inicie outra instalacao.");return;}
        message("Finalizacao recuperada","O pacote instalado corresponde ao candidato. current.cia foi atualizado; reinicie o console.");return;
    }
    if(!candidate.version){message("Estado ambiguo","Versao do candidato invalida.");return;}
    snprintf(backup,sizeof(backup),ROOT "/backup-%016llX-v%u.cia",(unsigned long long)candidate.title_id,candidate.version-1);
    if(!exists(backup)&&(candidate.title_id&255)==9)snprintf(backup,sizeof(backup),ROOT "/backup-%016llX-v%u.cia",(unsigned long long)((candidate.title_id&~255ULL)|0xFE),candidate.version-1);
    previous=exists(CURRENT)?CURRENT:exists(backup)?backup:select_base();
    if(tt_verify(previous,e)||tt_inspect(previous,&old,e)||(old.title_id!=candidate.title_id&& !((old.title_id&255)==0xFE&&(candidate.title_id&255)==9&&(old.title_id&~255ULL)==(candidate.title_id&~255ULL)&&target_absent(candidate.title_id,e)))||old.version+1!=candidate.version||!installed_matches(&old,0,e)){
        message("Recuperacao externa necessaria","O console nao corresponde ao candidato nem a base. Preserve pending.txt, as CIAs e log.txt. Consulte o README; nao apague titulos.");return;}
    if(!strcmp(previous,backup)&&rename(backup,CURRENT)){message("Erro restaurando base","Backup preservado.");return;}
    if(remove(JOURNAL)){message("Erro no diario","Estado anterior reconhecido, mas pending.txt nao foi removido.");return;}
    message("Estado anterior recuperado","O pacote anterior continua instalado. A CIA candidata foi mantida; SELECT permite descarta-la.");
}
static int journal(const char*base,const char*backup){FILE*f=fopen(JOURNAL,"wb");int bad;if(!f)return 0;
    bad=fprintf(f,"base=%s\nbackup=%s\ncandidate=%s\n",base,backup,CANDIDATE)<0;
    if(fflush(f)||fsync(fileno(f)))bad=1;if(fclose(f))bad=1;return !bad;}
static Result install_cia(const char*path){FILE*f=fopen(path,"rb");Handle handle=0;Result r;u64 offset=0;u8*buf=NULL;int active=0;struct stat st;size_t block=new_model?1048576:262144;
    if(stat(path,&st)||st.st_size<=0){if(f)fclose(f);return (Result)-1;}
    if(!f)return (Result)-1;buf=malloc(block);if(!buf){block=65536;buf=malloc(block);}if(!buf){fclose(f);return (Result)-1;}
    r=amInit();if(R_FAILED(r)){free(buf);fclose(f);return r;}
    aptSetSleepAllowed(false);aptSetHomeAllowed(false);
    r=AM_StartCiaInstall(MEDIATYPE_SD,&handle);if(R_FAILED(r))goto end;active=1;
    bottom_begin("Instalando catalogo");wrapped(49,"Nao desligue nem retire o SD.");frame();
    for(;;){size_t n=fread(buf,1,block,f);u32 written=0;if(!n){if(ferror(f))r=(Result)-1;break;}
        r=FSFILE_Write(handle,&written,offset,buf,(u32)n,0);if(R_FAILED(r)||written!=n){if(R_SUCCEEDED(r))r=(Result)-1;break;}offset+=n;
        progress_ui("Gravando catalogo no SD",65+(unsigned)(32*offset/(u64)st.st_size));}
    if(R_SUCCEEDED(r)&&offset!=(u64)st.st_size)r=(Result)-1;
    if(R_SUCCEEDED(r))progress_ui("Finalizando instalacao",98);
    if(R_SUCCEEDED(r)){r=AM_FinishCiaInstall(handle);active=0;}
    if(active)AM_CancelCIAInstall(handle);
end:aptSetHomeAllowed(true);aptSetSleepAllowed(true);amExit();free(buf);fclose(f);return r;}

static int add_theme(const char*input,int generate_only,int repair){char e[256],backup[256];const char*base=select_base();TTPackage p,c;Result result;int moved=0;
    if(!batch_auto){job_number=job_total=1;}job_percent=0;last_progress=0;
    if(input){size_t n=strlen(input);if(n>=4&&!strcasecmp(input+n-4,".cia")&&!tt_is_theme_cia(input)){message("CIA incompativel","Somente instaladores de temas com ZIP embutido sao aceitos. Jogos nao sao instalados.");return 0;}}
    if(exists(JOURNAL)){message("Recuperacao pendente","Existe pending.txt. Consulte o README antes de nova instalacao. Os arquivos de recuperacao foram mantidos.");return 0;}
    if(!cfw_ok(e)||tt_inspect(base,&p,e)||!region_ok(p.title_id,e)){message("Nao foi possivel continuar",e);return 0;}
    if(repair&&(!exists(CURRENT)||p.count<2)){message("Sem catalogo para reparar","Instale um tema primeiro. O reparo usa current.cia, sem precisar selecionar o tema original.");return 0;}
    if(!repair&&(p.title_id&255)==0xFE){message("Catalogo antigo detectado","Pressione L no navegador para reparar os temas ja adicionados. Depois adicione novos temas normalmente.");return 0;}
    if(!generate_only&&!installed_matches(&p,repair?0:1,e)){message("Instalacao bloqueada",e);return 0;}
    /* Candidate + retained package + AM import storage, with extra headroom. */
    if(!enough_space(2*(p.file_size+8*1024*1024ULL)+8*1024*1024ULL,e)){message("Verifique o SD",e);return 0;}
    if(exists(CANDIDATE)){message("CIA candidata ja existe","Guarde ou remova candidate.cia pelo computador antes de gerar outra. O arquivo nao sera sobrescrito.");return 0;}
    bottom_begin("Preparando catalogo");wrapped(49,"Verificando os arquivos...\nIsso pode levar alguns minutos.");frame();
    if(repair?tt_repair(base,CANDIDATE,e):tt_add(base,input,CANDIDATE,e)){logline(e);message("Tema nao adicionado",e);return 0;}
    if(tt_inspect(CANDIDATE,&c,e)){message("Erro no candidato",e);return 0;}
    if(c.title_id!=p.title_id&&!target_absent(c.title_id,e)){message("Migracao bloqueada",e);return 0;}
    snprintf(e,sizeof(e),"Preparado %016llX -> %016llX; temas=%u; reparo=%d",(unsigned long long)p.title_id,(unsigned long long)c.title_id,c.count-1,repair);logline(e);
    if(generate_only||(!batch_auto&&!confirmation())){message("CIA gerada; nada instalado","Arquivo: /3ds/scl-temas/candidate.cia\nA base permanece inalterada.");return 0;}
    if(!installed_matches(&p,repair?0:1,e)||(c.title_id!=p.title_id&&!target_absent(c.title_id,e))){message("Instalacao bloqueada",e);return 0;}
    snprintf(backup,sizeof(backup),ROOT "/backup-%016llX-v%u.cia",(unsigned long long)p.title_id,p.version);
    if(exists(backup)){message("Backup ja existe","Guarde o backup anterior antes de continuar. Ele nao sera sobrescrito.");return 0;}
    if(!journal(base,backup)){message("Sem diario de recuperacao","Nao foi possivel gravar pending.txt. Nada instalado.");return 0;}
    /* Preserve the exact old package BEFORE starting AM. Initial base.cia is kept. */
    if(!strcmp(base,CURRENT)){if(rename(CURRENT,backup)){remove(JOURNAL);message("Erro no backup","Nada instalado; current.cia preservado.");return 0;}moved=1;}
    result=install_cia(CANDIDATE);
    if(R_FAILED(result)){snprintf(e,sizeof(e),"AM retornou %08lX. Diario, candidato e base foram mantidos. Consulte recuperacao no README.",(u32)result);logline(e);message("Instalacao interrompida",e);return 0;}
    if(!installed_matches(&c,0,e)){logline(e);message("Verificacao pos-instalacao falhou",e);return 0;}
    if(rename(CANDIDATE,CURRENT)){message("Instalado; finalizacao pendente","Falha ao promover candidate.cia. Nao apague pending.txt; consulte o README.");return 0;}
    if(remove(JOURNAL)){message("Finalizacao pendente","Catalogo instalado. Diario preservado; use recuperacao. Nenhuma CIA de entrada foi apagada.");return 0;}snprintf(e,sizeof(e),"Instalado %016llX v%u; backup: %.200s",(unsigned long long)c.title_id,c.version,moved?backup:base);logline(e);
    progress_ui("Tema concluido",100);
    if(!batch_auto)message("Pacote instalado","Reinicie e abra Trocar tema para escolher o tema. A instalacao nao o aplica automaticamente. Se nao aparecer, preserve /3ds/scl-temas/log.txt e current.cia.");
    return 1;
}

static const char*filename(const char*p){const char*s=strrchr(p,'/');return s?s+1:p;}
static int queue_index(const char*p){unsigned i;for(i=0;i<queue_count;i++)if(!strcmp(queue[i].path,p))return (int)i;return -1;}
static int is_cia(const char*p){size_t n=strlen(p);return n>=4&&(!strcasecmp(p+n-4,".cia"));}
static void toggle_queue(const char*p){int index=queue_index(p);struct stat st;
    if(index>=0){memmove(queue+index,queue+index+1,(queue_count-index-1)*sizeof(*queue));queue_count--;return;}
    if(!is_cia(p)||stat(p,&st)||!S_ISREG(st.st_mode)){message("Selecao multipla","Marque arquivos CIA. Pastas sao abertas com A.");return;}
    if(!tt_is_theme_cia(p)){message("CIA incompativel","Arquivo nao reconhecido como instalador de tema. Nada instalado.");return;}
    if(queue_count==100){message("Fila cheia","Limite de 100 arquivos por fila.");return;}
    snprintf(queue[queue_count++].path,1024,"%s",p);
}
static int hash_input(const char*p,unsigned char hash[32]){FILE*f;unsigned char buffer[32768];size_t n;TTSha h;struct stat st;
    if(stat(p,&st)||!S_ISREG(st.st_mode))return 0;f=fopen(p,"rb");if(!f)return 0;tt_sha_init(&h);
    while((n=fread(buffer,1,sizeof(buffer),f)))tt_sha_update(&h,buffer,n);
    if(ferror(f)){fclose(f);return 0;}fclose(f);tt_sha_final(&h,hash);return 1;
}
static void appearance(void){int choice=light_theme,redraw=1;
    while(aptMainLoop()){if(redraw){ui_theme(choice);bottom_begin("Aparencia do aplicativo");
        ui_rect(8,64+choice*43,304,31,ui_colors.accent);
        ui_text(18,72,"01  Lista violeta",choice==0?0xffffff:ui_colors.text,35);
        ui_text(18,115,"03  Lilas claro",choice==1?0xffffff:ui_colors.text,35);
        ui_text(12,171,"Cima/baixo: escolher",ui_colors.muted,37);
        ui_text(12,193,"A: salvar    B: cancelar",ui_colors.text,37);frame();redraw=0;}
        {u32 down=key();if(down&(KEY_UP|KEY_DOWN)){choice=!choice;redraw=1;}
        if(down&KEY_B){ui_theme(light_theme);return;}
        if(down&KEY_A){FILE*f=fopen(ROOT "/e4-appearance.cfg","wb");int ok=0;
            if(f){int wrote=fputc('0'+choice,f)!=EOF;int flushed=fflush(f)==0;int synced=fsync(fileno(f))==0;int closed=fclose(f)==0;ok=wrote&&flushed&&synced&&closed;}
            light_theme=choice;ui_theme(light_theme);if(!ok)message("Preferencia nao salva","A aparencia mudou nesta sessao, mas nao foi possivel salvar no SD.");return;}}
        gspWaitForVBlank();
    }ui_theme(light_theme);
}
static void draw_browser(unsigned selected,int transition){unsigned i,start=selected/9*9;char text[96];unsigned char*fb=gfxGetFramebuffer(GFX_TOP,GFX_LEFT,NULL,NULL);
    ui_surface(fb,400);ui_clear();ui_rect(0,0,400,42,ui_colors.panel);ui_logo(8,5);ui_text(48,7,"E4Temas 1.1.1",ui_colors.text,28);
    snprintf(text,sizeof(text),"%u na fila",queue_count);ui_text(288,23,text,ui_colors.muted,13);
    ui_text(12,47,current_dir,ui_colors.muted,47);
    for(i=start;i<choice_count&&i<start+9;i++){int y=69+(int)(i-start)*18;uint32_t color=i==selected?0xffffff:ui_colors.text;
        if(i==selected)ui_rect(6,y-1,388,18,ui_colors.accent);
        ui_text(12,y,i==selected?">":" ",color,1);ui_text(28,y,choices[i].directory?"+":queue_index(choices[i].path)>=0?"*":" ",color,1);
        ui_text(44,y,choices[i].label,color,43);
    }
    if(!choice_count)ui_text(12,82,"Pasta vazia. B para voltar.",ui_colors.text,47);
    bottom_begin("Sua selecao");snprintf(text,sizeof(text),"%u tema(s) na fila",queue_count);ui_text(12,49,text,ui_colors.text,37);
    ui_text(12,73,"A: abrir / escolher CIA",ui_colors.text,37);
    ui_text(12,93,"X: marcar ou desmarcar",ui_colors.text,37);
    ui_rect(8,119,304,29,ui_colors.accent);ui_text(20,126,"Y: revisar e instalar fila",0xffffff,35);
    ui_text(12,160,"SELECT: aparencia",ui_colors.muted,37);
    ui_text(12,178,"R: ferramentas   L: reparar",ui_colors.muted,37);
    ui_text(12,196,"B: voltar        START: sair",ui_colors.muted,37);
    if(exists(JOURNAL))ui_text(12,220,"Recuperacao pendente: use R",0xd98649,37);
    else {snprintf(text,sizeof(text),"CIAs incompativeis ocultas: %u",hidden_cias);ui_text(12,220,text,ui_colors.muted,37);}
    if(transition&&have_previous){unsigned char*next=malloc(sizeof(previous_top));if(next){int step,x;memcpy(next,fb,sizeof(previous_top));
        for(step=1;step<=8&&aptMainLoop();step++){int shift=step*50;for(x=0;x<400;x++){
            int src=transition>0?x+shift:x-shift;
            if(src>=0&&src<400)memcpy(fb+x*720,previous_top+src*720,720);
            else{src=transition>0?src-400:src+400;memcpy(fb+x*720,next+src*720,720);}}
            frame();}
        memcpy(fb,next,sizeof(previous_top));free(next);}}
    memcpy(previous_top,fb,sizeof(previous_top));have_previous=1;frame();
}
static void review_queue(void){unsigned selected=0,done=0,i,removed=0,kept=0;int delete_inputs=0,redraw=1,approved=0;char text[256];TTPackage p;
    if(!queue_count){message("Fila vazia","Use X sobre as CIAs para escolher quantos temas deseja instalar.");return;}
    while(aptMainLoop()){
        if(redraw){ui_surface(gfxGetFramebuffer(GFX_TOP,GFX_LEFT,NULL,NULL),400);ui_clear();ui_rect(0,0,400,42,ui_colors.panel);
            snprintf(text,sizeof(text),"Revisar %u tema(s)",queue_count);ui_text(12,12,text,ui_colors.text,47);
            for(i=selected/9*9;i<queue_count&&i<selected/9*9+9;i++){int y=55+(int)(i%9)*19;if(i==selected)ui_rect(6,y-1,388,19,ui_colors.accent);ui_text(12,y,filename(queue[i].path),i==selected?0xffffff:ui_colors.text,47);}
            bottom_begin("Opcoes da instalacao");ui_rect(8,52,304,53,ui_colors.panel);ui_text(16,58,"Apagar CIAs apos instalar",ui_colors.text,35);
            ui_text(16,79,delete_inputs?"[SIM]  X para alterar":"[NAO]  X para alterar",ui_colors.accent,35);
            ui_text(12,119,"1 por vez; apaga so ao concluir.",ui_colors.muted,37);
            ui_text(12,143,"Cima/baixo: revisar os arquivos",ui_colors.text,37);
            ui_rect(8,172,304,30,ui_colors.accent);ui_text(20,180,"L + R + A: instalar",0xffffff,35);
            ui_text(12,219,"B: voltar sem instalar",ui_colors.muted,37);frame();redraw=0;}
        {u32 down=key();if(down&KEY_B)return;if(down&KEY_X){delete_inputs=!delete_inputs;redraw=1;}
            if(down&KEY_DOWN){selected=(selected+1)%queue_count;redraw=1;}if(down&KEY_UP){selected=selected?selected-1:queue_count-1;redraw=1;}
            if((down&KEY_A)&&(hidKeysHeld()&KEY_L)&&(hidKeysHeld()&KEY_R)){approved=1;break;}}
        gspWaitForVBlank();
    }
    if(!approved)return;
    if(exists(JOURNAL)||exists(CANDIDATE)){message("Operacao pendente","Use R: recupere a operacao pendente ou descarte o candidato antes de instalar a fila.");return;}
    if(tt_inspect(select_base(),&p,text)||p.count+queue_count>TT_MAX_CONTENTS){message("Limite da colecao","A fila ultrapassa 100 temas ou a base nao pode ser lida.");return;}
    pending_additions=queue_count;i=installed_matches(&p,1,text);pending_additions=1;
    if(!i){message("Instalacao bloqueada",text);return;}
    bottom_begin("Verificando fila");wrapped(49,"Conferindo os arquivos de entrada...");frame();
    for(i=0;i<queue_count;i++)if(!hash_input(queue[i].path,queue[i].hash)){message("Arquivo indisponivel",queue[i].path);return;}
    batch_auto=1;job_total=queue_count;
    for(done=0;done<queue_count;done++){
        unsigned char hash[32];
        if(!hash_input(queue[done].path,hash)||memcmp(hash,queue[done].hash,32)){message("Arquivo mudou",queue[done].path);break;}
        job_number=done+1;
        if(!add_theme(queue[done].path,0,0))break;
    }
    batch_auto=0;
    if(done!=queue_count){unsigned remaining=queue_count-done;
        memmove(queue,queue+done,remaining*sizeof(*queue));queue_count=remaining;
        snprintf(text,sizeof(text),"%u instalados; %u restantes.\nNenhuma CIA de entrada foi apagada.\nOs instalados foram retirados da fila.\nSe houver diario pendente, use R.",done,remaining);message("Fila interrompida",text);return;}
    if(delete_inputs&&exists(JOURNAL))kept=queue_count;
    if(delete_inputs&&!exists(JOURNAL))for(i=0;i<queue_count;i++){
        unsigned char hash[32];
        if(e4_can_delete_input(queue[i].path)&&hash_input(queue[i].path,hash)&&!memcmp(hash,queue[i].hash,32)&&!remove(queue[i].path)){removed++;logline("CIA de entrada removida apos conclusao da fila");}
        else kept++;
    }
    snprintf(text,sizeof(text),"%u temas instalados.\nCIAs apagadas: %u.\nCIAs mantidas: %u.\n\nReinicie e abra Trocar tema para escolher.\nO catalogo e os backups foram mantidos.",done,removed,delete_inputs?kept:done);
    queue_count=0;message("Fila concluida",text);
}
static void tools_menu(unsigned selected){bottom_begin("Ferramentas");wrapped(49,"L: reparar catalogo\nR: verificar recuperacao\nX: descartar CIA candidata\nY: gerar arquivo atual sem instalar\nA: atualizar lista\nB: voltar");frame();
    while(aptMainLoop()){u32 down=key();if(down&KEY_B)return;if(down&KEY_L){add_theme(NULL,0,1);return;}if(down&KEY_R){recover();return;}
        if(down&KEY_X){discard_candidate();return;}if(down&KEY_A){rescan();return;}
        if((down&KEY_Y)&&choice_count&&!choices[selected].directory){add_theme(choices[selected].path,1,0);return;}gspWaitForVBlank();}
}
int main(void){unsigned selected=0;int redraw=1,transition=0;char e[256];ThemeBootInfo boot;Result resource_result;
    startup_begin("e4temas",&boot);{bool n=false;if(R_SUCCEEDED(APT_CheckNew3DS(&n))&&n){new_model=1;osSetSpeedupEnable(true);}}tt_set_progress(progress_ui);startup_record("gfx.begin",0);gfxInitDefault();startup_record("gfx.ready",0);
    resource_result=romfsInit();startup_record("romfs.mount",resource_result);
    if(R_SUCCEEDED(resource_result)&&R_SUCCEEDED(boot.detected_result)&&boot.detected&&R_SUCCEEDED(boot.writable_result)&&boot.writable){startup_record("intro.begin",0);e4_intro();startup_record("intro.end",0);}
    gfxSetDoubleBuffering(GFX_TOP,false);gfxSetDoubleBuffering(GFX_BOTTOM,false);ui_theme(0);
    if(R_FAILED(resource_result)||R_FAILED(boot.detected_result)||!boot.detected||R_FAILED(boot.writable_result)||!boot.writable){
        snprintf(e,sizeof(e),"SD: %u (%08lX)\nGravavel: %u (%08lX)\nRomFS: %08lX\nNenhum tema foi instalado.",boot.detected,(u32)boot.detected_result,boot.writable,(u32)boot.writable_result,(u32)resource_result);
        message("Falha na inicializacao",e);if(R_SUCCEEDED(resource_result))romfsExit();gfxExit();return 1;
    }
    mkdir("sdmc:/3ds",0777);mkdir(ROOT,0777);mkdir(ROOT "/inbox",0777);
    {FILE*f=fopen(ROOT "/e4-appearance.cfg","rb");if(f){light_theme=fgetc(f)=='1';fclose(f);}}ui_theme(light_theme);
    rescan();startup_record("ui.ready",0);
    while(aptMainLoop()){
        if(redraw){draw_browser(selected,transition);transition=0;redraw=0;}
        {u32 down=key();if(down&KEY_START)break;
            if((down&KEY_DOWN)&&choice_count){selected=(selected+1)%choice_count;redraw=1;}
            if((down&KEY_UP)&&choice_count){selected=selected?selected-1:choice_count-1;redraw=1;}
            if(down&KEY_B){parent_dir();rescan();selected=0;transition=-1;redraw=1;}
            if(down&KEY_SELECT){appearance();redraw=1;}
            if(down&KEY_R){tools_menu(selected);selected=0;redraw=1;}
            if(down&KEY_L){add_theme(NULL,0,1);redraw=1;}
            if((down&KEY_X)&&choice_count){toggle_queue(choices[selected].path);redraw=1;}
            if(down&KEY_Y){review_queue();rescan();selected=0;redraw=1;}
            if((down&KEY_A)&&choice_count){
                if(choices[selected].directory){snprintf(current_dir,sizeof(current_dir),"%s",choices[selected].path);rescan();selected=0;transition=1;}
                else if(is_cia(choices[selected].path)){if(queue_index(choices[selected].path)<0)toggle_queue(choices[selected].path);review_queue();rescan();selected=0;}
                else add_theme(choices[selected].path,0,0);
                redraw=1;
            }}
        gspWaitForVBlank();
    }tt_set_progress(NULL);if(new_model)osSetSpeedupEnable(false);romfsExit();gfxExit();return 0;
}
