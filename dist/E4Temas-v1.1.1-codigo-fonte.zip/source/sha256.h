#ifndef TT_SHA256_H
#define TT_SHA256_H
#include <stdint.h>
#include <stddef.h>
typedef struct {uint32_t h[8];uint64_t length;size_t used;unsigned char buf[64];} TTSha;
void tt_sha_init(TTSha *s);
void tt_sha_update(TTSha *s,const void *p,size_t n);
void tt_sha_final(TTSha *s,unsigned char hash[32]);
#endif
