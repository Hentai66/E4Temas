#ifndef TT_IMPORT_H
#define TT_IMPORT_H
#include <stddef.h>
/* Reads a bounded asset from an extracted folder or a single-theme ZIP. */
unsigned char *tt_asset(const char *input,const char *name,size_t *size,size_t maximum);
int tt_png_icon(const unsigned char *png,size_t size,unsigned char icon[4608]);
#endif
