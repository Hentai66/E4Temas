/* Native playback of the user's E4T HTML animation, pre-rendered from its SVG. */
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
static unsigned le16(const unsigned char *p){return p[0]|((unsigned)p[1]<<8);}
static uint32_t le32(const unsigned char *p){return le16(p)|((uint32_t)le16(p+2)<<16);}
void e4_intro(void){
    FILE *file=fopen("romfs:/intro.e4a","rb");unsigned char header[12],sizebuf[4];
    unsigned frames,fps,frame;unsigned char *bottom;
    if(!file)return;
    if(fread(header,1,12,file)!=12||header[0]!='E'||header[1]!='4'||header[2]!='A'||header[3]!='1'||le16(header+4)!=400||le16(header+6)!=240){fclose(file);return;}
    frames=le16(header+8);fps=le16(header+10);
    if(!frames||frames>120||!fps||fps>60){fclose(file);return;}
    for(frame=0;frame<frames;frame++){
        uint32_t bytes,offset=0,pixel=0;unsigned char *encoded,*fb;int valid=1;
        hidScanInput();if(hidKeysDown()&(KEY_A|KEY_B|KEY_START))break;
        if(!aptMainLoop()||fread(sizebuf,1,4,file)!=4)break;
        bytes=le32(sizebuf);if(!bytes||bytes>400*240*4||(bytes&3))break;
        encoded=malloc(bytes);if(!encoded)break;
        if(fread(encoded,1,bytes,file)!=bytes){free(encoded);break;}
        fb=gfxGetFramebuffer(GFX_TOP,GFX_LEFT,NULL,NULL);
        bottom=gfxGetFramebuffer(GFX_BOTTOM,GFX_LEFT,NULL,NULL);
        for(unsigned i=0;i<320*240;i++){bottom[i*3]=29;bottom[i*3+1]=27;bottom[i*3+2]=24;}
        while(offset<bytes){unsigned count=le16(encoded+offset),color=le16(encoded+offset+2);unsigned r=(color>>11)&31,g=(color>>5)&63,b=color&31;offset+=4;
            if(!count||count>400*240-pixel){valid=0;break;}
            while(count--){unsigned x=pixel%400,y=pixel/400,index=(x*240+239-y)*3;
                fb[index]=(b<<3)|(b>>2);fb[index+1]=(g<<2)|(g>>4);fb[index+2]=(r<<3)|(r>>2);pixel++;}
        }
        free(encoded);if(!valid||pixel!=400*240)break;
        gfxFlushBuffers();gfxSwapBuffers();for(unsigned wait=0;wait<60/fps;wait++)gspWaitForVBlank();
    }
    fclose(file);
}
